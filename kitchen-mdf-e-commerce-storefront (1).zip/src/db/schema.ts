import {
  boolean,
  integer,
  jsonb,
  pgTable,
  real,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export type Variant = { id: string; label: string; price: number };
export type Spec = { label: string; value: string };

export const collections = pgTable("collections", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  tagline: text("tagline").notNull(),
  description: text("description").notNull(),
  image: text("image").notNull(),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  collectionSlug: text("collection_slug").notNull(),
  shortDescription: text("short_description").notNull(),
  description: text("description").notNull(),
  price: integer("price").notNull(), // cents, base / "from" price
  compareAtPrice: integer("compare_at_price"),
  unit: text("unit").notNull().default("each"),
  finish: text("finish").notNull(),
  thickness: integer("thickness").notNull(), // mm
  moistureResistant: boolean("moisture_resistant").notNull().default(false),
  images: jsonb("images").$type<string[]>().notNull(),
  variants: jsonb("variants").$type<Variant[]>().notNull(),
  specs: jsonb("specs").$type<Spec[]>().notNull(),
  highlights: jsonb("highlights").$type<string[]>().notNull(),
  badge: text("badge"),
  featured: boolean("featured").notNull().default(false),
  stock: integer("stock").notNull().default(100),
  rating: real("rating").notNull().default(0),
  reviewCount: integer("review_count").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").notNull(),
  author: text("author").notNull(),
  location: text("location"),
  rating: integer("rating").notNull(),
  title: text("title").notNull(),
  body: text("body").notNull(),
  verified: boolean("verified").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type OrderItem = {
  productId: number;
  slug: string;
  name: string;
  image: string;
  variantId: string;
  variantLabel: string;
  unitPrice: number;
  quantity: number;
};

export type OrderAddress = {
  firstName: string;
  lastName: string;
  company?: string;
  address1: string;
  address2?: string;
  city: string;
  postcode: string;
  country: string;
  phone?: string;
};

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  reference: text("reference").notNull().unique(),
  email: text("email").notNull(),
  address: jsonb("address").$type<OrderAddress>().notNull(),
  items: jsonb("items").$type<OrderItem[]>().notNull(),
  shippingMethod: text("shipping_method").notNull(),
  subtotal: integer("subtotal").notNull(),
  shipping: integer("shipping").notNull(),
  tax: integer("tax").notNull(),
  total: integer("total").notNull(),
  status: text("status").notNull().default("confirmed"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type Collection = typeof collections.$inferSelect;
export type Product = typeof products.$inferSelect;
export type Review = typeof reviews.$inferSelect;
export type Order = typeof orders.$inferSelect;
