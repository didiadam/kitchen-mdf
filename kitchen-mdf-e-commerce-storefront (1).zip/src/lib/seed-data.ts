import type { Spec, Variant } from "@/db/schema";

const px = (id: number) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&w=1400`;

export const IMG = {
  hero: "/images/hero.jpg",
  boards: "/images/mdf-boards.jpg",
  mr: "/images/mr-mdf.jpg",
  shaker: "/images/shaker-door.jpg",
  slab: "/images/slab-door.jpg",
  gloss: "/images/gloss-panel.jpg",
  oak: "/images/oak-veneer.jpg",
  primed: "/images/primed-door.jpg",
  drawers: "/images/drawer-fronts.jpg",
  workshop: "/images/workshop.jpg",
  kitchenWood: px(6489116),
  kitchenMatte: px(7061400),
  kitchenWhite: px(7587733),
  kitchenMono: px(7061393),
  kitchenOak: px(8089082),
  kitchenLux: px(7167061),
  kitchenPendant: px(6283972),
  kitchenGrey: px(7031759),
  plywood: px(7479035),
  blueTiles: px(37030080),
  greyCabinets: px(7746657),
  blueDrawer: px(10117700),
  blueKitchen: px(34558075),
  brassHandles: px(35287566),
  whiteDoors: px(25525670),
  joiner: px(5974248),
  saw: px(32357250),
  sander: px(5710910),
  samples: px(7505175),
};

export type SeedCollection = {
  slug: string;
  name: string;
  tagline: string;
  description: string;
  image: string;
  sortOrder: number;
};

export const seedCollections: SeedCollection[] = [
  {
    slug: "mdf-boards",
    name: "MDF Boards",
    tagline: "The honest foundation",
    description:
      "Full sheets of premium European MDF — standard, moisture resistant, fire retardant and ultralight — cut square and ready for your workshop.",
    image: IMG.boards,
    sortOrder: 1,
  },
  {
    slug: "cabinet-doors",
    name: "Cabinet Doors",
    tagline: "Made-to-measure fronts",
    description:
      "CNC-routed MDF doors in shaker, slab, V-groove and handleless profiles. Supplied primed or factory spray-painted in our signature palette.",
    image: IMG.shaker,
    sortOrder: 2,
  },
  {
    slug: "lacquered-veneered",
    name: "Lacquered & Veneered",
    tagline: "Surfaces that glow",
    description:
      "Mirror-gloss lacquers and real-wood veneers bonded to precision MDF cores for flawless, stable panels.",
    image: IMG.oak,
    sortOrder: 3,
  },
  {
    slug: "kitchen-components",
    name: "Kitchen Components",
    tagline: "The finishing details",
    description:
      "Drawer fronts, décor end panels, plinths and cornice — everything to complete a seamless MDF kitchen.",
    image: IMG.drawers,
    sortOrder: 4,
  },
];

export type SeedProduct = {
  slug: string;
  name: string;
  collectionSlug: string;
  shortDescription: string;
  description: string;
  compareAtPrice?: number;
  unit: string;
  finish: string;
  thickness: number;
  moistureResistant: boolean;
  images: string[];
  variants: Variant[];
  specs: Spec[];
  highlights: string[];
  badge?: string;
  featured: boolean;
  stock: number;
  daysAgo: number;
  reviewPool: keyof typeof reviewPools;
};

const sizeVariants = (base: number, step: number, tall: number): Variant[] => [
  { id: "715x297", label: "715 × 297 mm", price: base },
  { id: "715x397", label: "715 × 397 mm", price: base + step },
  { id: "715x497", label: "715 × 497 mm", price: base + step * 2 },
  { id: "715x597", label: "715 × 597 mm", price: base + step * 3 },
  { id: "2150x597", label: "2150 × 597 mm (tall)", price: tall },
];

export const seedProducts: SeedProduct[] = [
  {
    slug: "standard-mdf-sheet",
    name: "Standard MDF Sheet",
    collectionSlug: "mdf-boards",
    shortDescription: "E1 low-formaldehyde MDF with a tight, uniform core and silky faces.",
    description:
      "Our everyday workhorse. Sourced from FSC® certified European mills, this E1-grade MDF has a dense, homogenous core that machines cleanly, routs without tear-out and takes paint beautifully. Every sheet is inspected, edge-protected and delivered flat on our own fleet.",
    unit: "per sheet",
    finish: "Raw",
    thickness: 18,
    moistureResistant: false,
    images: [IMG.boards, IMG.plywood, IMG.saw, IMG.workshop],
    variants: [
      { id: "6mm", label: "6 mm · 2440 × 1220", price: 1850 },
      { id: "12mm", label: "12 mm · 2440 × 1220", price: 2690 },
      { id: "18mm", label: "18 mm · 2440 × 1220", price: 3450 },
      { id: "25mm", label: "25 mm · 2440 × 1220", price: 4600 },
    ],
    specs: [
      { label: "Sheet size", value: "2440 × 1220 mm (8 × 4 ft)" },
      { label: "Density", value: "720–760 kg/m³" },
      { label: "Emission class", value: "E1 (≤ 0.1 ppm)" },
      { label: "Certification", value: "FSC® Mix Credit" },
      { label: "Tolerance", value: "± 0.2 mm thickness" },
    ],
    highlights: ["Routs cleanly, no tear-out", "Paint-ready smooth faces", "Delivered flat & edge-protected"],
    badge: "Best seller",
    featured: true,
    stock: 420,
    daysAgo: 220,
    reviewPool: "boards",
  },
  {
    slug: "moisture-resistant-mdf",
    name: "Moisture Resistant MDF",
    collectionSlug: "mdf-boards",
    shortDescription: "Green-core MR MDF engineered for kitchens, utility rooms and bathrooms.",
    description:
      "The trade standard for kitchen carcasses and doors. MR resins give this board its distinctive green core and a far greater tolerance to humidity than standard MDF, while keeping the fine machining qualities joiners love. Ideal for sink units, plinths and anywhere steam or splashes are a fact of life.",
    unit: "per sheet",
    finish: "Raw",
    thickness: 18,
    moistureResistant: true,
    images: [IMG.mr, IMG.boards, IMG.sander, IMG.kitchenMatte],
    variants: [
      { id: "12mm", label: "12 mm · 2440 × 1220", price: 3490 },
      { id: "18mm", label: "18 mm · 2440 × 1220", price: 4450 },
      { id: "25mm", label: "25 mm · 2440 × 1220", price: 5800 },
    ],
    specs: [
      { label: "Sheet size", value: "2440 × 1220 mm" },
      { label: "Standard", value: "EN 622-5 MDF.H" },
      { label: "Thickness swell (24h)", value: "≤ 8%" },
      { label: "Core colour", value: "Green (identification)" },
      { label: "Emission class", value: "E1" },
    ],
    highlights: ["Rated for humid areas", "Green core for easy ID", "Ideal for sink & utility units"],
    badge: "Trade favourite",
    featured: true,
    stock: 310,
    daysAgo: 200,
    reviewPool: "boards",
  },
  {
    slug: "fire-retardant-mdf",
    name: "Fire Retardant MDF",
    collectionSlug: "mdf-boards",
    shortDescription: "Euroclass B-s2,d0 certified board for commercial fit-outs.",
    description:
      "Specified for restaurants, hotels and public spaces where fire performance is non-negotiable. Treated throughout the core, not just the surface, so it retains its rating after machining. Supplied with full certification for your building control file.",
    unit: "per sheet",
    finish: "Raw",
    thickness: 18,
    moistureResistant: false,
    images: [IMG.boards, IMG.saw, IMG.samples],
    variants: [
      { id: "12mm", label: "12 mm · 2440 × 1220", price: 5250 },
      { id: "18mm", label: "18 mm · 2440 × 1220", price: 6200 },
    ],
    specs: [
      { label: "Fire rating", value: "Euroclass B-s2,d0" },
      { label: "Sheet size", value: "2440 × 1220 mm" },
      { label: "Core colour", value: "Red / pink (identification)" },
      { label: "Documentation", value: "Certificate supplied with order" },
    ],
    highlights: ["Through-core treatment", "Certificates included", "Commercial specification"],
    featured: false,
    stock: 95,
    daysAgo: 160,
    reviewPool: "boards",
  },
  {
    slug: "pre-primed-mdf-board",
    name: "Pre-Primed MDF Board",
    collectionSlug: "mdf-boards",
    shortDescription: "Factory primed both faces — skip a step and go straight to topcoat.",
    description:
      "A high-build, sanded acrylic primer applied on our finishing line to both faces. It seals the fibres, eliminates grain-raising and saves you a full day on every project. Perfect for bespoke panelling, alcove units and painted cabinetry.",
    unit: "per sheet",
    finish: "Primed",
    thickness: 18,
    moistureResistant: true,
    images: [IMG.primed, IMG.boards, IMG.workshop],
    variants: [
      { id: "9mm", label: "9 mm · 2440 × 1220", price: 3990 },
      { id: "18mm", label: "18 mm · 2440 × 1220", price: 5200 },
    ],
    specs: [
      { label: "Primer", value: "Water-based acrylic, sanded 240 grit" },
      { label: "Core", value: "MR MDF" },
      { label: "Faces primed", value: "Both faces (edges raw)" },
      { label: "Sheet size", value: "2440 × 1220 mm" },
    ],
    highlights: ["Saves a full priming day", "Sealed, ultra-smooth faces", "Moisture resistant core"],
    badge: "New",
    featured: false,
    stock: 140,
    daysAgo: 12,
    reviewPool: "boards",
  },
  {
    slug: "ultralight-mdf",
    name: "Ultralight MDF",
    collectionSlug: "mdf-boards",
    shortDescription: "Up to 30% lighter than standard MDF — kinder on backs and hinges.",
    description:
      "A lower-density board that keeps a smooth, paintable face while shedding serious weight. Loved by fitters for tall larder doors, wall units and anything that has to be carried up three flights of stairs.",
    compareAtPrice: 4400,
    unit: "per sheet",
    finish: "Raw",
    thickness: 18,
    moistureResistant: false,
    images: [IMG.boards, IMG.plywood, IMG.joiner],
    variants: [
      { id: "12mm", label: "12 mm · 2440 × 1220", price: 2990 },
      { id: "18mm", label: "18 mm · 2440 × 1220", price: 3890 },
    ],
    specs: [
      { label: "Density", value: "≈ 500 kg/m³" },
      { label: "Weight (18mm sheet)", value: "≈ 27 kg" },
      { label: "Sheet size", value: "2440 × 1220 mm" },
      { label: "Emission class", value: "E1" },
    ],
    highlights: ["30% lighter", "Smooth paintable face", "Great for tall doors"],
    badge: "Sale",
    featured: false,
    stock: 80,
    daysAgo: 90,
    reviewPool: "boards",
  },
  {
    slug: "hartley-shaker-door-sage",
    name: "Hartley Shaker Door — Sage",
    collectionSlug: "cabinet-doors",
    shortDescription: "Classic 70mm-frame shaker, factory sprayed in our Sage matte.",
    description:
      "The Hartley is our most-loved profile: a crisp 70mm frame, 6mm recessed centre panel and gently eased edges, CNC-routed from a single piece of 18mm MR MDF so there are no joints to crack. Finished with three coats of hard-wearing 2K matte lacquer in Sage — a softened green that works with brass, marble and warm oak.",
    unit: "per door",
    finish: "Painted",
    thickness: 18,
    moistureResistant: true,
    images: [IMG.shaker, IMG.hero, IMG.brassHandles, IMG.kitchenMatte],
    variants: sizeVariants(6400, 700, 16800),
    specs: [
      { label: "Core", value: "18 mm MR MDF, one-piece routed" },
      { label: "Frame width", value: "70 mm" },
      { label: "Finish", value: "2K PU lacquer, 10% sheen" },
      { label: "Colour", value: "Sage (NCS S 5010-G30Y equivalent)" },
      { label: "Hinge drilling", value: "Optional 35 mm cups — add note at checkout" },
      { label: "Lead time", value: "10 working days" },
    ],
    highlights: ["One-piece, no joints to crack", "Hard-wearing 2K lacquer", "Hinge drilling available"],
    badge: "Best seller",
    featured: true,
    stock: 200,
    daysAgo: 180,
    reviewPool: "doors",
  },
  {
    slug: "hartley-shaker-door-primed",
    name: "Hartley Shaker Door — Primed",
    collectionSlug: "cabinet-doors",
    shortDescription: "Our signature shaker, primed and sanded — ready for your colour.",
    description:
      "Everything you love about the Hartley, supplied in a sanded white primer so you can finish it in any shade. Perfect for Farrow & Ball or Little Greene enthusiasts and for replacing doors on existing carcasses.",
    unit: "per door",
    finish: "Primed",
    thickness: 18,
    moistureResistant: true,
    images: [IMG.primed, IMG.shaker, IMG.kitchenWhite],
    variants: sizeVariants(3800, 450, 9900),
    specs: [
      { label: "Core", value: "18 mm MR MDF, one-piece routed" },
      { label: "Frame width", value: "70 mm" },
      { label: "Finish", value: "Sanded white acrylic primer" },
      { label: "Lead time", value: "5 working days" },
    ],
    highlights: ["Paint in any colour", "Fits standard carcasses", "Fast 5-day lead time"],
    featured: true,
    stock: 260,
    daysAgo: 170,
    reviewPool: "doors",
  },
  {
    slug: "linea-j-pull-door-charcoal",
    name: "Linea J-Pull Door — Charcoal",
    collectionSlug: "cabinet-doors",
    shortDescription: "Handleless slab with integrated J-pull, in velvety charcoal lacquer.",
    description:
      "Architectural minimalism. The Linea is machined with a sculpted J-pull along its top edge for a clean, handleless run of units. Finished in a super-matt anti-fingerprint charcoal lacquer that feels like velvet and hides everyday smudges.",
    unit: "per door",
    finish: "Lacquered",
    thickness: 22,
    moistureResistant: true,
    images: [IMG.slab, IMG.kitchenMono, IMG.kitchenLux],
    variants: sizeVariants(7200, 800, 18900),
    specs: [
      { label: "Core", value: "22 mm MR MDF" },
      { label: "Pull profile", value: "Integrated J-pull, 20 mm lip" },
      { label: "Finish", value: "Super-matt anti-fingerprint lacquer" },
      { label: "Colour", value: "Charcoal" },
      { label: "Lead time", value: "12 working days" },
    ],
    highlights: ["Seamless handleless look", "Anti-fingerprint surface", "Premium 22mm core"],
    badge: "Designer pick",
    featured: true,
    stock: 120,
    daysAgo: 60,
    reviewPool: "doors",
  },
  {
    slug: "brampton-v-groove-door",
    name: "Brampton V-Groove Door",
    collectionSlug: "cabinet-doors",
    shortDescription: "Tongue-and-groove style for a relaxed, cottage-kitchen character.",
    description:
      "Evenly spaced vertical V-grooves give the Brampton the charm of traditional boarded doors with none of the movement. Supplied primed for painting — beautiful in chalky whites, soft blues and deep greens.",
    unit: "per door",
    finish: "Primed",
    thickness: 18,
    moistureResistant: true,
    images: [IMG.primed, IMG.blueKitchen, IMG.blueTiles],
    variants: sizeVariants(3400, 400, 8900),
    specs: [
      { label: "Core", value: "18 mm MR MDF" },
      { label: "Groove spacing", value: "100 mm centres" },
      { label: "Finish", value: "Sanded white primer" },
      { label: "Lead time", value: "5 working days" },
    ],
    highlights: ["Cottage character", "Stable — no board movement", "Primed & ready to paint"],
    featured: false,
    stock: 150,
    daysAgo: 140,
    reviewPool: "doors",
  },
  {
    slug: "ashby-slab-door-oat",
    name: "Ashby Slab Door — Oat",
    collectionSlug: "cabinet-doors",
    shortDescription: "Pure flat slab with 2mm radius edges in a warm oat matte.",
    description:
      "Quiet, calm and endlessly versatile. The Ashby is a flat slab with softly radiused edges, finished in Oat — a warm, milky neutral that pairs perfectly with timber worktops and brushed steel.",
    compareAtPrice: 5900,
    unit: "per door",
    finish: "Painted",
    thickness: 18,
    moistureResistant: true,
    images: [IMG.kitchenWhite, IMG.kitchenWood, IMG.whiteDoors],
    variants: sizeVariants(4900, 550, 12900),
    specs: [
      { label: "Core", value: "18 mm MR MDF" },
      { label: "Edge", value: "2 mm radius" },
      { label: "Finish", value: "2K PU lacquer, 10% sheen" },
      { label: "Colour", value: "Oat" },
    ],
    highlights: ["Soft radiused edges", "Warm neutral tone", "Pairs with timber tops"],
    badge: "Sale",
    featured: false,
    stock: 90,
    daysAgo: 45,
    reviewPool: "doors",
  },
  {
    slug: "lumiere-high-gloss-panel",
    name: "Lumière High-Gloss Panel",
    collectionSlug: "lacquered-veneered",
    shortDescription: "Mirror-finish white lacquer on precision MDF — 90+ gloss units.",
    description:
      "Seven coats of polyester lacquer, flatted and polished to a flawless mirror finish that reflects light around the room. Supplied with protective film. Ideal for contemporary doors, splashback cladding and feature walls.",
    unit: "per panel",
    finish: "High Gloss",
    thickness: 18,
    moistureResistant: false,
    images: [IMG.gloss, IMG.kitchenWhite, IMG.kitchenPendant],
    variants: [
      { id: "1220x600", label: "1220 × 600 mm", price: 8900 },
      { id: "2440x600", label: "2440 × 600 mm", price: 15900 },
      { id: "2440x1220", label: "2440 × 1220 mm", price: 28900 },
    ],
    specs: [
      { label: "Gloss level", value: "≥ 90 GU" },
      { label: "Faces", value: "One face gloss, reverse balancer" },
      { label: "Protection", value: "Peel-off film" },
      { label: "Core", value: "18 mm MDF" },
    ],
    highlights: ["Mirror-like 90+ GU finish", "Protective film supplied", "Balanced to stay flat"],
    featured: true,
    stock: 60,
    daysAgo: 75,
    reviewPool: "panels",
  },
  {
    slug: "crown-cut-oak-veneered-mdf",
    name: "Crown Cut Oak Veneered MDF",
    collectionSlug: "lacquered-veneered",
    shortDescription: "A-grade European oak veneer, book-matched on a stable MDF core.",
    description:
      "0.6mm crown-cut European oak with its characteristic cathedral figure, pressed onto both faces of premium MDF. Sand lightly and oil, lacquer or stain — you get the warmth of solid oak with total dimensional stability.",
    unit: "per sheet",
    finish: "Veneered",
    thickness: 19,
    moistureResistant: false,
    images: [IMG.oak, IMG.kitchenOak, IMG.samples],
    variants: [
      { id: "6mm", label: "6 mm · 2440 × 1220", price: 6900 },
      { id: "12mm", label: "12 mm · 2440 × 1220", price: 8400 },
      { id: "19mm", label: "19 mm · 2440 × 1220", price: 9800 },
    ],
    specs: [
      { label: "Veneer", value: "0.6 mm European oak, crown cut" },
      { label: "Grade", value: "A face / B reverse" },
      { label: "Core", value: "E1 MDF" },
      { label: "Finish", value: "Unfinished — sand, then oil or lacquer" },
    ],
    highlights: ["Real oak, total stability", "A-grade face", "Takes oils & stains"],
    badge: "Natural",
    featured: true,
    stock: 70,
    daysAgo: 110,
    reviewPool: "panels",
  },
  {
    slug: "american-walnut-veneered-mdf",
    name: "American Walnut Veneered MDF",
    collectionSlug: "lacquered-veneered",
    shortDescription: "Rich, chocolate-toned walnut veneer for statement joinery.",
    description:
      "Deep, lustrous American black walnut with a quarter-cut stripe, laid up on both faces of an MR MDF core. Our go-to for island cladding, open shelving and bespoke bar units.",
    unit: "per sheet",
    finish: "Veneered",
    thickness: 19,
    moistureResistant: true,
    images: [IMG.oak, IMG.kitchenWood, IMG.joiner],
    variants: [
      { id: "12mm", label: "12 mm · 2440 × 1220", price: 11900 },
      { id: "19mm", label: "19 mm · 2440 × 1220", price: 13900 },
    ],
    specs: [
      { label: "Veneer", value: "0.6 mm American black walnut, quarter cut" },
      { label: "Grade", value: "A face / B reverse" },
      { label: "Core", value: "MR MDF" },
    ],
    highlights: ["Luxurious deep tones", "Quarter-cut stripe", "MR core"],
    featured: false,
    stock: 40,
    daysAgo: 30,
    reviewPool: "panels",
  },
  {
    slug: "hartley-drawer-front-navy",
    name: "Hartley Drawer Front — Navy",
    collectionSlug: "kitchen-components",
    shortDescription: "Slim-frame shaker drawer fronts in deep Navy matte.",
    description:
      "Designed to sit perfectly alongside Hartley doors, with a proportionally slimmer 50mm frame for shallow drawers. Sprayed in Navy — a deep, inky blue that looks spectacular with brass cup handles.",
    unit: "per front",
    finish: "Painted",
    thickness: 18,
    moistureResistant: true,
    images: [IMG.drawers, IMG.blueDrawer, IMG.blueKitchen],
    variants: [
      { id: "140x397", label: "140 × 397 mm", price: 2900 },
      { id: "140x597", label: "140 × 597 mm", price: 3400 },
      { id: "283x597", label: "283 × 597 mm", price: 4200 },
      { id: "283x797", label: "283 × 797 mm", price: 4900 },
    ],
    specs: [
      { label: "Core", value: "18 mm MR MDF" },
      { label: "Frame width", value: "50 mm" },
      { label: "Finish", value: "2K PU lacquer, 10% sheen" },
      { label: "Colour", value: "Navy" },
    ],
    highlights: ["Matches Hartley doors", "Deep inky navy", "Perfect with brass"],
    featured: true,
    stock: 180,
    daysAgo: 150,
    reviewPool: "components",
  },
  {
    slug: "decor-end-panel",
    name: "Décor End Panel",
    collectionSlug: "kitchen-components",
    shortDescription: "Full-height end panels to finish runs and islands beautifully.",
    description:
      "Finish exposed carcass sides with a solid 18mm décor panel matched to your doors. Available primed or sprayed in any of our colours — tell us which in the order notes.",
    unit: "per panel",
    finish: "Primed",
    thickness: 18,
    moistureResistant: true,
    images: [IMG.greyCabinets, IMG.kitchenGrey, IMG.primed],
    variants: [
      { id: "base", label: "Base · 900 × 600 mm", price: 5400 },
      { id: "wall", label: "Wall · 720 × 330 mm", price: 3600 },
      { id: "tall", label: "Tall · 2300 × 600 mm", price: 12400 },
    ],
    specs: [
      { label: "Core", value: "18 mm MR MDF" },
      { label: "Finish", value: "Primed (painted options on request)" },
      { label: "Edges", value: "All four edges sealed" },
    ],
    highlights: ["Hides carcass edges", "Matches any door", "All edges sealed"],
    featured: false,
    stock: 110,
    daysAgo: 100,
    reviewPool: "components",
  },
  {
    slug: "plinth-kickboard",
    name: "Plinth / Kickboard",
    collectionSlug: "kitchen-components",
    shortDescription: "Moisture-resistant plinth lengths with sealed bottom edge.",
    description:
      "The unsung hero of every kitchen. Machined from MR MDF with a factory-sealed lower edge to shrug off mop water, and supplied in 3m lengths to minimise joins.",
    unit: "per length",
    finish: "Primed",
    thickness: 16,
    moistureResistant: true,
    images: [IMG.kitchenMatte, IMG.kitchenMono, IMG.boards],
    variants: [
      { id: "100", label: "100 mm × 3 m", price: 2400 },
      { id: "150", label: "150 mm × 3 m", price: 2900 },
    ],
    specs: [
      { label: "Core", value: "16 mm MR MDF" },
      { label: "Length", value: "3000 mm" },
      { label: "Bottom edge", value: "Factory sealed" },
    ],
    highlights: ["3m lengths, fewer joins", "Sealed against mop water", "Primed to match"],
    featured: false,
    stock: 300,
    daysAgo: 190,
    reviewPool: "components",
  },
];

type SeedReview = {
  author: string;
  location: string;
  rating: number;
  title: string;
  body: string;
};

export const reviewPools: Record<"boards" | "doors" | "panels" | "components", SeedReview[]> = {
  boards: [
    { author: "Tom Whitaker", location: "Leeds", rating: 5, title: "Consistently flat, consistently good", body: "I get through 30–40 sheets a month in my joinery shop. These are dead flat, thicknesses are spot on and the faces take primer without any fluffing. Delivery driver even helped me stack them." },
    { author: "Priya Nair", location: "Bristol", rating: 5, title: "Perfect for my alcove units", body: "First big DIY project and the boards made it easy. Cut beautifully with a track saw, edges came out crisp. The corner protectors meant nothing arrived dinged." },
    { author: "Gareth Evans", location: "Cardiff", rating: 4, title: "Great board, book delivery early", body: "Quality is excellent — better than the merchant down the road. Only knocked a star because the next-day slots went quickly, so plan ahead." },
    { author: "Hannah Clarke", location: "Norwich", rating: 5, title: "Routs like butter", body: "Used these for a set of routed wardrobe doors. No tear-out, no voids in the core. Will be buying again for the kitchen." },
    { author: "Liam O'Connor", location: "Manchester", rating: 5, title: "Trade account is worth it", body: "Pricing is fair and the quality is reliable, which matters more to me than saving a quid. Paperwork and certificates arrive with the order every time." },
    { author: "Sophie Turner", location: "Brighton", rating: 4, title: "Heavy but superb", body: "Solid, dense sheets — you'll want two people. Painted finish came out glassy after two coats of primer." },
  ],
  doors: [
    { author: "Charlotte Bennett", location: "Harrogate", rating: 5, title: "Transformed our kitchen for a fraction of the cost", body: "We kept our carcasses and replaced every door with the Hartley in Sage. The finish is flawless — friends assume it's a £30k bespoke kitchen. Hinge drilling was perfect." },
    { author: "James Holloway", location: "Oxford", rating: 5, title: "Beautifully made", body: "The one-piece construction is a real selling point. Edges are crisp, lacquer is tough — two kids and a dog and not a chip after six months." },
    { author: "Emma Richardson", location: "Edinburgh", rating: 5, title: "Colour is even better in person", body: "I ordered a sample first, then 22 doors. Every one matched exactly. Packaging was excellent, each door individually wrapped." },
    { author: "Daniel Price", location: "Birmingham", rating: 4, title: "Great doors, allow the full lead time", body: "Took the full 10 days as quoted, but they were worth waiting for. Customer service answered all my sizing questions quickly." },
    { author: "Rachel Moore", location: "York", rating: 5, title: "Fitters were impressed", body: "Our fitter said they were some of the best MDF doors he'd hung — square, true and no warping at all on the tall larder doors." },
    { author: "Oliver Grant", location: "London", rating: 5, title: "Handleless dream", body: "Linea J-pull in charcoal looks incredibly sleek. The anti-fingerprint finish genuinely works — makes a huge difference with a busy family." },
    { author: "Megan Hughes", location: "Swansea", rating: 4, title: "Painted them myself — easy", body: "Bought primed and finished with two coats of eggshell. Primer was well sanded so it went on smoothly. Very happy." },
  ],
  panels: [
    { author: "Alex Morgan", location: "Glasgow", rating: 5, title: "Genuinely mirror-like", body: "The gloss panels were used as a splashback cladding and they look like glass. Protective film peeled away cleanly with no residue." },
    { author: "Fiona Campbell", location: "Aberdeen", rating: 5, title: "Gorgeous oak figure", body: "Beautiful cathedral grain across the whole sheet. Oiled it with hardwax and it glows. Stable too — no cupping on our open shelves." },
    { author: "Marcus Reid", location: "Newcastle", rating: 4, title: "Lovely veneer, careful with edges", body: "Veneer quality is top-notch. Use a sharp blade and scoring pass to avoid chipping on cross cuts — that's on me, not the board." },
    { author: "Isabel Foster", location: "Bath", rating: 5, title: "Island cladding looks stunning", body: "The walnut is so rich. We clad our island and it's the first thing everyone comments on." },
    { author: "Nathan Shaw", location: "Sheffield", rating: 5, title: "Great for commercial jobs", body: "Used gloss panels on a salon reception desk. Client was delighted and the balanced back means they've stayed perfectly flat." },
  ],
  components: [
    { author: "Lucy Adams", location: "Cambridge", rating: 5, title: "Perfect match to the doors", body: "Drawer fronts matched our Hartley doors exactly — same colour batch, same profile proportions. Brass handles on navy is a dream." },
    { author: "Ben Carter", location: "Nottingham", rating: 5, title: "Finishing touches done right", body: "End panels and plinths arrived together with the doors, all labelled. Made the fit so much easier." },
    { author: "Grace Kelly", location: "Belfast", rating: 4, title: "Solid quality", body: "Really good quality plinth, sealed edge is a nice detail. Would love a 200mm option for our taller plinth." },
    { author: "Sam Patel", location: "Leicester", rating: 5, title: "Navy is sumptuous", body: "Deep, rich colour with a lovely soft sheen. Even better than the photos." },
    { author: "Ella Wright", location: "Exeter", rating: 5, title: "Great service", body: "Called to check sizes and the team were patient and knowledgeable. Everything arrived in perfect condition." },
  ],
};
