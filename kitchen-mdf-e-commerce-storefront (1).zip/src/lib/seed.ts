import { pool } from "@/db";
import { reviewPools, seedCollections, seedProducts } from "./seed-data";

const DDL = `
CREATE TABLE IF NOT EXISTS collections (
  id serial PRIMARY KEY,
  slug text NOT NULL,
  name text NOT NULL,
  tagline text NOT NULL,
  description text NOT NULL,
  image text NOT NULL,
  sort_order integer NOT NULL DEFAULT 0,
  CONSTRAINT collections_slug_unique UNIQUE (slug)
);
CREATE TABLE IF NOT EXISTS products (
  id serial PRIMARY KEY,
  slug text NOT NULL,
  name text NOT NULL,
  collection_slug text NOT NULL,
  short_description text NOT NULL,
  description text NOT NULL,
  price integer NOT NULL,
  compare_at_price integer,
  unit text NOT NULL DEFAULT 'each',
  finish text NOT NULL,
  thickness integer NOT NULL,
  moisture_resistant boolean NOT NULL DEFAULT false,
  images jsonb NOT NULL,
  variants jsonb NOT NULL,
  specs jsonb NOT NULL,
  highlights jsonb NOT NULL,
  badge text,
  featured boolean NOT NULL DEFAULT false,
  stock integer NOT NULL DEFAULT 100,
  rating real NOT NULL DEFAULT 0,
  review_count integer NOT NULL DEFAULT 0,
  created_at timestamp NOT NULL DEFAULT now(),
  CONSTRAINT products_slug_unique UNIQUE (slug)
);
CREATE TABLE IF NOT EXISTS reviews (
  id serial PRIMARY KEY,
  product_id integer NOT NULL,
  author text NOT NULL,
  location text,
  rating integer NOT NULL,
  title text NOT NULL,
  body text NOT NULL,
  verified boolean NOT NULL DEFAULT false,
  created_at timestamp NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS orders (
  id serial PRIMARY KEY,
  reference text NOT NULL,
  email text NOT NULL,
  address jsonb NOT NULL,
  items jsonb NOT NULL,
  shipping_method text NOT NULL,
  subtotal integer NOT NULL,
  shipping integer NOT NULL,
  tax integer NOT NULL,
  total integer NOT NULL,
  status text NOT NULL DEFAULT 'confirmed',
  created_at timestamp NOT NULL DEFAULT now(),
  CONSTRAINT orders_reference_unique UNIQUE (reference)
);
`;

async function runSeed() {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    await client.query("SELECT pg_advisory_xact_lock(918273645)");
    await client.query(DDL);
    const { rows } = await client.query<{ count: string }>("SELECT count(*)::text AS count FROM products");
    if (Number(rows[0].count) > 0) {
      await client.query("COMMIT");
      return;
    }

    for (const c of seedCollections) {
      await client.query(
        `INSERT INTO collections (slug, name, tagline, description, image, sort_order)
         VALUES ($1,$2,$3,$4,$5,$6) ON CONFLICT (slug) DO NOTHING`,
        [c.slug, c.name, c.tagline, c.description, c.image, c.sortOrder],
      );
    }

    const day = 24 * 60 * 60 * 1000;
    for (let i = 0; i < seedProducts.length; i++) {
      const p = seedProducts[i];
      const pool = reviewPools[p.reviewPool];
      const count = 3 + ((i * 7) % 4); // 3–6 reviews
      const picked = Array.from({ length: Math.min(count, pool.length) }, (_, k) => pool[(i + k) % pool.length]);
      const avg = picked.reduce((s, r) => s + r.rating, 0) / picked.length;
      const price = Math.min(...p.variants.map((v) => v.price));
      const createdAt = new Date(Date.now() - p.daysAgo * day);

      const res = await client.query<{ id: number }>(
        `INSERT INTO products (slug, name, collection_slug, short_description, description, price, compare_at_price,
          unit, finish, thickness, moisture_resistant, images, variants, specs, highlights, badge, featured, stock,
          rating, review_count, created_at)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21)
         RETURNING id`,
        [
          p.slug, p.name, p.collectionSlug, p.shortDescription, p.description, price, p.compareAtPrice ?? null,
          p.unit, p.finish, p.thickness, p.moistureResistant, JSON.stringify(p.images), JSON.stringify(p.variants),
          JSON.stringify(p.specs), JSON.stringify(p.highlights), p.badge ?? null, p.featured, p.stock,
          Math.round(avg * 10) / 10, picked.length, createdAt,
        ],
      );
      const productId = res.rows[0].id;
      for (let k = 0; k < picked.length; k++) {
        const r = picked[k];
        const reviewDate = new Date(Date.now() - Math.max(1, Math.floor(p.daysAgo * (k + 1) / (picked.length + 1))) * day);
        await client.query(
          `INSERT INTO reviews (product_id, author, location, rating, title, body, verified, created_at)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
          [productId, r.author, r.location, r.rating, r.title, r.body, k % 5 !== 3, reviewDate],
        );
      }
    }
    await client.query("COMMIT");
  } catch (err) {
    await client.query("ROLLBACK").catch(() => {});
    throw err;
  } finally {
    client.release();
  }
}

const g = globalThis as typeof globalThis & { __kmdfSeed?: Promise<void> };

export function ensureSeeded(): Promise<void> {
  if (!g.__kmdfSeed) {
    g.__kmdfSeed = runSeed().catch((err) => {
      g.__kmdfSeed = undefined;
      throw err;
    });
  }
  return g.__kmdfSeed;
}
