import { and, asc, desc, eq, ne } from "drizzle-orm";
import { db } from "@/db";
import { collections, orders, products, reviews } from "@/db/schema";
import { ensureSeeded } from "./seed";

export async function getCollections() {
  await ensureSeeded();
  return db.select().from(collections).orderBy(asc(collections.sortOrder));
}

export async function getProducts() {
  await ensureSeeded();
  return db.select().from(products).orderBy(desc(products.featured), asc(products.id));
}

export async function getFeaturedProducts(limit = 8) {
  await ensureSeeded();
  return db.select().from(products).where(eq(products.featured, true)).orderBy(asc(products.id)).limit(limit);
}

export async function getProductBySlug(slug: string) {
  await ensureSeeded();
  const rows = await db.select().from(products).where(eq(products.slug, slug)).limit(1);
  return rows[0] ?? null;
}

export async function getRelatedProducts(collectionSlug: string, excludeId: number, limit = 4) {
  await ensureSeeded();
  return db
    .select()
    .from(products)
    .where(and(eq(products.collectionSlug, collectionSlug), ne(products.id, excludeId)))
    .orderBy(desc(products.rating))
    .limit(limit);
}

export async function getReviews(productId: number) {
  await ensureSeeded();
  return db.select().from(reviews).where(eq(reviews.productId, productId)).orderBy(desc(reviews.createdAt));
}

export async function getLatestReviews(limit = 6) {
  await ensureSeeded();
  return db
    .select({
      id: reviews.id,
      author: reviews.author,
      location: reviews.location,
      rating: reviews.rating,
      title: reviews.title,
      body: reviews.body,
      productName: products.name,
      productSlug: products.slug,
    })
    .from(reviews)
    .innerJoin(products, eq(reviews.productId, products.id))
    .where(eq(reviews.rating, 5))
    .orderBy(desc(reviews.createdAt))
    .limit(limit);
}

export async function getOrderByReference(reference: string) {
  await ensureSeeded();
  const rows = await db.select().from(orders).where(eq(orders.reference, reference)).limit(1);
  return rows[0] ?? null;
}
