export const CURRENCY = "GBP";

const fmt = new Intl.NumberFormat("en-GB", { style: "currency", currency: CURRENCY });

export function formatPrice(cents: number) {
  return fmt.format(cents / 100);
}

export function formatDate(d: Date | string) {
  return new Date(d).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" });
}

export type ShippingMethod = { id: string; label: string; detail: string; price: number };

export const FREE_SHIPPING_THRESHOLD = 50000; // £500

export const SHIPPING_METHODS: ShippingMethod[] = [
  { id: "standard", label: "Standard delivery", detail: "3–5 working days · our own fleet", price: 2900 },
  { id: "express", label: "Next-day delivery", detail: "Order by 1pm, Mon–Fri", price: 5900 },
  { id: "collect", label: "Collect from our Sheffield yard", detail: "Ready in 24 hours", price: 0 },
];

export function shippingCost(methodId: string, subtotal: number) {
  const m = SHIPPING_METHODS.find((s) => s.id === methodId) ?? SHIPPING_METHODS[0];
  if (m.id === "standard" && subtotal >= FREE_SHIPPING_THRESHOLD) return 0;
  return m.price;
}

/** Prices include 20% UK VAT; returns the VAT portion. */
export function vatIncluded(total: number) {
  return Math.round(total - total / 1.2);
}
