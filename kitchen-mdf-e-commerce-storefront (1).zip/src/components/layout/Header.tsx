"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { useCart } from "../cart/CartProvider";
import { Icon } from "../ui";

const NAV = [
  { href: "/shop", label: "Shop all" },
  { href: "/shop?collection=mdf-boards", label: "MDF Boards" },
  { href: "/shop?collection=cabinet-doors", label: "Doors" },
  { href: "/shop?collection=lacquered-veneered", label: "Panels" },
  { href: "/shop?collection=kitchen-components", label: "Components" },
];

export function Header() {
  const { count, open, hydrated } = useCart();
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [bump, setBump] = useState(false);
  const transparent = pathname === "/" && !scrolled && !menuOpen;

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setMenuOpen(false);
  }, [pathname]);

  useEffect(() => {
    if (!hydrated || count === 0) return;
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setBump(true);
    const t = setTimeout(() => setBump(false), 400);
    return () => clearTimeout(t);
  }, [count, hydrated]);

  if (pathname?.startsWith("/checkout")) {
    return (
      <header className="border-b border-ink/10 bg-cream">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-5">
          <Logo />
          <span className="flex items-center gap-2 text-xs text-stone">
            <Icon name="lock" className="h-4 w-4" /> Secure checkout
          </span>
        </div>
      </header>
    );
  }

  return (
    <>
      <div className="bg-ink text-cream">
        <div className="mx-auto flex max-w-7xl items-center justify-center gap-6 px-5 py-2 text-[0.7rem] tracking-wide">
          <span>Free delivery on orders over £500</span>
          <span className="hidden text-cream/40 sm:inline">•</span>
          <span className="hidden sm:inline">Cut-to-size service · Trade accounts welcome</span>
        </div>
      </div>
      <header
        className={`sticky top-0 z-50 transition-all duration-500 ${
          transparent ? "bg-transparent text-cream" : "bg-cream/90 text-ink shadow-[0_1px_0_rgba(0,0,0,0.06)] backdrop-blur-md"
        } ${pathname === "/" ? "-mb-[73px]" : ""}`}
      >
        <div className="mx-auto flex h-[73px] max-w-7xl items-center justify-between px-5">
          <button className="rounded-full p-2 lg:hidden" onClick={() => setMenuOpen((v) => !v)} aria-label="Menu">
            <Icon name={menuOpen ? "close" : "menu"} />
          </button>
          <Logo />
          <nav className="hidden items-center gap-8 lg:flex">
            {NAV.map((n) => (
              <Link key={n.href} href={n.href} className="group relative text-sm tracking-wide">
                {n.label}
                <span className="absolute -bottom-1 left-0 h-px w-0 bg-current transition-all duration-300 group-hover:w-full" />
              </Link>
            ))}
          </nav>
          <div className="flex items-center gap-1">
            <Link href="/shop" className="hidden rounded-full p-2 transition hover:bg-current/10 sm:block" aria-label="Search products">
              <Icon name="search" />
            </Link>
            <button onClick={open} className="relative rounded-full p-2 transition hover:bg-current/10" aria-label={`Open cart, ${count} items`}>
              <Icon name="bag" />
              {hydrated && count > 0 && (
                <span
                  className={`absolute -right-0.5 -top-0.5 grid h-5 min-w-5 place-items-center rounded-full bg-brass px-1 text-[0.65rem] font-semibold text-white transition-transform ${
                    bump ? "scale-125" : "scale-100"
                  }`}
                >
                  {count}
                </span>
              )}
            </button>
          </div>
        </div>
        <div className={`overflow-hidden border-t border-ink/10 bg-cream text-ink transition-[max-height] duration-500 lg:hidden ${menuOpen ? "max-h-96" : "max-h-0 border-transparent"}`}>
          <nav className="flex flex-col px-5 py-3">
            {NAV.map((n) => (
              <Link key={n.href} href={n.href} className="border-b border-ink/5 py-3 font-display text-lg last:border-0">
                {n.label}
              </Link>
            ))}
          </nav>
        </div>
      </header>
    </>
  );
}

export function Logo({ light = false }: { light?: boolean }) {
  return (
    <Link href="/" className={`flex items-center gap-2.5 ${light ? "text-cream" : ""}`}>
      <span className="grid h-9 w-9 place-items-center rounded-full border border-current">
        <span className="font-display text-sm italic">K</span>
      </span>
      <span className="leading-none">
        <span className="block font-display text-xl tracking-tight">Kitchen MDF</span>
        <span className="block text-[0.55rem] uppercase tracking-[0.3em] opacity-70">Board to Door</span>
      </span>
    </Link>
  );
}
