"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { Logo } from "./Header";

export function Footer() {
  const pathname = usePathname();
  const [email, setEmail] = useState("");
  const [done, setDone] = useState(false);
  if (pathname?.startsWith("/checkout")) return null;

  return (
    <footer className="grain bg-ink text-cream">
      <div className="mx-auto max-w-7xl px-5 py-16">
        <div className="grid gap-12 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <Logo light />
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-cream/60">
              Premium MDF boards, made-to-measure doors and finishing panels — from raw board to finished kitchen, supplied direct from our Sheffield workshop since 2009.
            </p>
            <form
              className="mt-6 flex max-w-sm gap-2"
              onSubmit={(e) => {
                e.preventDefault();
                if (email.includes("@")) setDone(true);
              }}
            >
              {done ? (
                <p className="text-sm text-brass-light">Thank you — check your inbox for 10% off your first order.</p>
              ) : (
                <>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Email for 10% off"
                    className="min-w-0 flex-1 rounded-full border border-cream/20 bg-transparent px-4 py-2.5 text-sm outline-none placeholder:text-cream/40 focus:border-brass"
                  />
                  <button className="rounded-full bg-brass px-5 py-2.5 text-sm font-medium text-ink transition hover:bg-brass-light">Join</button>
                </>
              )}
            </form>
          </div>
          <FooterCol
            title="Shop"
            links={[
              ["/shop?collection=mdf-boards", "MDF Boards"],
              ["/shop?collection=cabinet-doors", "Cabinet Doors"],
              ["/shop?collection=lacquered-veneered", "Lacquered & Veneered"],
              ["/shop?collection=kitchen-components", "Kitchen Components"],
            ]}
          />
          <FooterCol
            title="Services"
            links={[
              ["/shop", "Cut-to-size"],
              ["/shop", "Hinge drilling"],
              ["/shop", "Colour matching"],
              ["/shop", "Trade accounts"],
            ]}
          />
          <FooterCol
            title="Help"
            links={[
              ["/shop", "Delivery & returns"],
              ["/shop", "Measuring guide"],
              ["/shop", "Care & finishing"],
              ["/shop", "Contact: 0114 496 0321"],
            ]}
          />
        </div>
        <div className="mt-14 flex flex-col gap-3 border-t border-cream/10 pt-6 text-xs text-cream/40 sm:flex-row sm:justify-between">
          <p>© {new Date().getFullYear()} Kitchen MDF Ltd. Registered in England & Wales.</p>
          <p>FSC® certified supply · E1 low emission · Prices include VAT</p>
        </div>
      </div>
    </footer>
  );
}

function FooterCol({ title, links }: { title: string; links: [string, string][] }) {
  return (
    <div>
      <h4 className="font-sans text-xs font-semibold uppercase tracking-[0.2em] text-brass-light">{title}</h4>
      <ul className="mt-5 space-y-3 text-sm text-cream/70">
        {links.map(([href, label]) => (
          <li key={label}>
            <Link href={href} className="transition hover:text-cream">
              {label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
