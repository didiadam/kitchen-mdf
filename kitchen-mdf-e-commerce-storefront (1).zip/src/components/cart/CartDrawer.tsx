"use client";

import Link from "next/link";
import { useCart } from "./CartProvider";
import { Icon } from "../ui";
import { FREE_SHIPPING_THRESHOLD, formatPrice } from "@/lib/format";

export function CartDrawer() {
  const { items, isOpen, close, subtotal, count, updateQuantity, removeItem, lastAdded } = useCart();
  const remaining = Math.max(0, FREE_SHIPPING_THRESHOLD - subtotal);
  const progress = Math.min(100, (subtotal / FREE_SHIPPING_THRESHOLD) * 100);

  return (
    <div className={`fixed inset-0 z-[60] ${isOpen ? "pointer-events-auto" : "pointer-events-none"}`} aria-hidden={!isOpen}>
      <div
        onClick={close}
        className={`absolute inset-0 bg-ink/40 backdrop-blur-[2px] transition-opacity duration-500 ${isOpen ? "opacity-100" : "opacity-0"}`}
      />
      <aside
        role="dialog"
        aria-label="Shopping cart"
        className={`absolute right-0 top-0 flex h-full w-full max-w-md flex-col bg-cream shadow-2xl transition-transform duration-500 ease-[cubic-bezier(0.22,1,0.36,1)] ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <header className="flex items-center justify-between border-b border-ink/10 px-6 py-5">
          <div>
            <h2 className="text-2xl">Your basket</h2>
            <p className="text-xs text-stone">{count} {count === 1 ? "item" : "items"}</p>
          </div>
          <button onClick={close} className="rounded-full p-2 transition hover:bg-ink/5" aria-label="Close cart">
            <Icon name="close" />
          </button>
        </header>

        {items.length > 0 && (
          <div className="border-b border-ink/10 px-6 py-4">
            <p className="text-xs text-graphite">
              {remaining > 0 ? (
                <>You&apos;re <strong>{formatPrice(remaining)}</strong> away from free standard delivery</>
              ) : (
                <>🎉 You&apos;ve unlocked <strong>free standard delivery</strong></>
              )}
            </p>
            <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-ink/10">
              <div className="h-full rounded-full bg-sage transition-all duration-700" style={{ width: `${progress}%` }} />
            </div>
          </div>
        )}

        <div className="flex-1 overflow-y-auto px-6">
          {items.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center text-center">
              <div className="mb-5 grid h-20 w-20 place-items-center rounded-full bg-linen">
                <Icon name="bag" className="h-8 w-8 text-stone" />
              </div>
              <h3 className="text-xl">Your basket is empty</h3>
              <p className="mt-2 max-w-xs text-sm text-stone">Explore premium boards, doors and panels crafted for beautiful kitchens.</p>
              <Link href="/shop" onClick={close} className="btn-primary mt-6">
                Start shopping
              </Link>
            </div>
          ) : (
            <ul className="divide-y divide-ink/10">
              {items.map((item) => (
                <li
                  key={item.key}
                  className={`flex gap-4 py-5 ${item.key === lastAdded ? "animate-fade-up" : ""}`}
                >
                  <Link href={`/products/${item.slug}`} onClick={close} className="h-24 w-20 shrink-0 overflow-hidden rounded-lg bg-linen">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={item.image} alt={item.name} className="h-full w-full object-cover" />
                  </Link>
                  <div className="flex min-w-0 flex-1 flex-col">
                    <div className="flex justify-between gap-3">
                      <div className="min-w-0">
                        <Link href={`/products/${item.slug}`} onClick={close} className="block truncate font-display text-base hover:text-sage">
                          {item.name}
                        </Link>
                        <p className="text-xs text-stone">{item.variantLabel}</p>
                      </div>
                      <p className="whitespace-nowrap text-sm font-medium">{formatPrice(item.price * item.quantity)}</p>
                    </div>
                    <div className="mt-auto flex items-center justify-between pt-3">
                      <div className="flex items-center rounded-full border border-ink/15">
                        <button onClick={() => updateQuantity(item.key, item.quantity - 1)} className="p-2 hover:text-sage" aria-label="Decrease quantity">
                          <Icon name="minus" className="h-3.5 w-3.5" />
                        </button>
                        <span className="w-7 text-center text-sm tabular-nums">{item.quantity}</span>
                        <button onClick={() => updateQuantity(item.key, item.quantity + 1)} className="p-2 hover:text-sage" aria-label="Increase quantity">
                          <Icon name="plus" className="h-3.5 w-3.5" />
                        </button>
                      </div>
                      <button onClick={() => removeItem(item.key)} className="text-xs text-stone underline-offset-4 hover:text-ink hover:underline">
                        Remove
                      </button>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {items.length > 0 && (
          <footer className="border-t border-ink/10 bg-linen/60 px-6 py-5">
            <div className="flex items-baseline justify-between">
              <span className="text-sm text-graphite">Subtotal</span>
              <span className="font-display text-2xl">{formatPrice(subtotal)}</span>
            </div>
            <p className="mt-1 text-xs text-stone">Prices include VAT. Delivery calculated at checkout.</p>
            <Link href="/checkout" onClick={close} className="btn-primary mt-4 w-full">
              <Icon name="lock" className="h-4 w-4" /> Secure checkout
            </Link>
            <button onClick={close} className="mt-3 w-full text-center text-xs text-stone underline-offset-4 hover:text-ink hover:underline">
              Continue shopping
            </button>
          </footer>
        )}
      </aside>
    </div>
  );
}
