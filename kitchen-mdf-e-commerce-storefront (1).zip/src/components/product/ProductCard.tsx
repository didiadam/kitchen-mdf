"use client";

import Link from "next/link";
import type { Product } from "@/db/schema";
import { formatPrice } from "@/lib/format";
import { useCart } from "../cart/CartProvider";
import { Icon, Stars } from "../ui";

export function ProductCard({ product, priority = false }: { product: Product; priority?: boolean }) {
  const { addItem } = useCart();
  const minVariant = product.variants.reduce((a, b) => (b.price < a.price ? b : a), product.variants[0]);
  const multiple = product.variants.length > 1;

  return (
    <article className="group relative flex flex-col">
      <div className="relative">
      <Link href={`/products/${product.slug}`} className="relative block aspect-[4/5] overflow-hidden rounded-2xl bg-linen">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={product.images[0]}
          alt={product.name}
          loading={priority ? "eager" : "lazy"}
          className="absolute inset-0 h-full w-full object-cover transition-all duration-[1.2s] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-105"
        />
        {product.images[1] && (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={product.images[1]}
            alt=""
            loading="lazy"
            className="absolute inset-0 h-full w-full object-cover opacity-0 transition-opacity duration-700 group-hover:opacity-100"
          />
        )}
        {product.badge && (
          <span
            className={`absolute left-3 top-3 rounded-full px-3 py-1 text-[0.65rem] font-semibold uppercase tracking-wider ${
              product.badge === "Sale" ? "bg-brass text-white" : "bg-cream/95 text-ink"
            }`}
          >
            {product.badge}
          </span>
        )}
        {product.moistureResistant && (
          <span className="absolute right-3 top-3 rounded-full bg-sage/90 px-2.5 py-1 text-[0.6rem] font-semibold uppercase tracking-wider text-white">
            MR
          </span>
        )}
      </Link>
      <button
        onClick={() =>
          addItem({
            productId: product.id,
            slug: product.slug,
            name: product.name,
            image: product.images[0],
            variantId: minVariant.id,
            variantLabel: minVariant.label,
            price: minVariant.price,
          })
        }
        className="absolute inset-x-3 bottom-3 hidden translate-y-2 items-center justify-center gap-2 rounded-full bg-cream/95 py-2.5 text-xs font-medium tracking-wide text-ink opacity-0 shadow-lg backdrop-blur transition-all duration-300 hover:bg-ink hover:text-cream group-hover:translate-y-0 group-hover:opacity-100 md:flex"
        aria-label={`Quick add ${product.name}`}
      >
        <Icon name="plus" className="h-3.5 w-3.5" /> Quick add · {minVariant.label.split("·")[0].trim()}
      </button>
      </div>
      <div className="mt-4 flex flex-1 flex-col">
        <div className="flex items-center gap-2">
          <Stars rating={product.rating} size={12} />
          <span className="text-xs text-stone">({product.reviewCount})</span>
        </div>
        <Link href={`/products/${product.slug}`} className="mt-1.5 font-display text-lg leading-snug transition-colors hover:text-sage">
          {product.name}
        </Link>
        <p className="mt-1 line-clamp-2 text-sm text-stone">{product.shortDescription}</p>
        <div className="mt-3 flex items-baseline gap-2">
          <span className="text-base font-medium">
            {multiple && <span className="text-xs font-normal text-stone">From </span>}
            {formatPrice(product.price)}
          </span>
          {product.compareAtPrice && product.compareAtPrice > product.price && (
            <span className="text-sm text-stone line-through">{formatPrice(product.compareAtPrice)}</span>
          )}
          <span className="text-xs text-stone">{product.unit}</span>
        </div>
      </div>
    </article>
  );
}
