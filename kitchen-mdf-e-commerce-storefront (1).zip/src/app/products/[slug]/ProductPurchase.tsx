"use client";

import { useState } from "react";
import type { Variant } from "@/db/schema";
import { useCart } from "@/components/cart/CartProvider";
import { Icon } from "@/components/ui";
import { formatPrice } from "@/lib/format";

type Props = {
  product: { id: number; slug: string; name: string; image: string; unit: string; compareAtPrice: number | null; basePrice: number; stock: number };
  variants: Variant[];
};

export function ProductPurchase({ product, variants }: Props) {
  const { addItem } = useCart();
  const [variantId, setVariantId] = useState(variants[0]?.id);
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);
  const variant = variants.find((v) => v.id === variantId) ?? variants[0];
  const compare = product.compareAtPrice ? Math.round((product.compareAtPrice / product.basePrice) * variant.price) : null;

  const add = () => {
    addItem(
      {
        productId: product.id,
        slug: product.slug,
        name: product.name,
        image: product.image,
        variantId: variant.id,
        variantLabel: variant.label,
        price: variant.price,
      },
      qty,
    );
    setAdded(true);
    setTimeout(() => setAdded(false), 1800);
  };

  return (
    <div>
      <div className="flex items-baseline gap-3">
        <span key={variant.id} className="animate-fade-in font-display text-4xl">{formatPrice(variant.price)}</span>
        {compare && compare > variant.price && <span className="text-lg text-stone line-through">{formatPrice(compare)}</span>}
        <span className="text-sm text-stone">{product.unit} · inc. VAT</span>
      </div>

      {variants.length > 1 && (
        <fieldset className="mt-8">
          <legend className="mb-3 flex w-full justify-between text-sm">
            <span className="font-medium">Size / thickness</span>
            <span className="text-stone">{variant.label}</span>
          </legend>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
            {variants.map((v) => (
              <button
                key={v.id}
                type="button"
                onClick={() => setVariantId(v.id)}
                className={`rounded-xl border px-3 py-3 text-left text-xs transition ${
                  v.id === variant.id ? "border-ink bg-ink text-cream shadow-md" : "border-ink/15 bg-white/50 hover:border-ink/40"
                }`}
              >
                <span className="block font-medium">{v.label.split("·")[0]}</span>
                <span className={v.id === variant.id ? "text-cream/70" : "text-stone"}>
                  {v.label.includes("·") ? `${v.label.split("·")[1].trim()} · ` : ""}{formatPrice(v.price)}
                </span>
              </button>
            ))}
          </div>
        </fieldset>
      )}

      <div className="mt-8 flex gap-3">
        <div className="flex items-center rounded-full border border-ink/15 bg-white/50">
          <button onClick={() => setQty((q) => Math.max(1, q - 1))} className="p-3.5 hover:text-sage" aria-label="Decrease quantity">
            <Icon name="minus" className="h-4 w-4" />
          </button>
          <input
            value={qty}
            onChange={(e) => setQty(Math.max(1, Math.min(99, Number(e.target.value.replace(/\D/g, "")) || 1)))}
            className="w-10 bg-transparent text-center tabular-nums outline-none"
            aria-label="Quantity"
          />
          <button onClick={() => setQty((q) => Math.min(99, q + 1))} className="p-3.5 hover:text-sage" aria-label="Increase quantity">
            <Icon name="plus" className="h-4 w-4" />
          </button>
        </div>
        <button onClick={add} className="btn-primary flex-1">
          {added ? (
            <><Icon name="check" className="h-4 w-4" /> Added to basket</>
          ) : (
            <>Add to basket · {formatPrice(variant.price * qty)}</>
          )}
        </button>
      </div>
      <p className="mt-4 flex items-center gap-2 text-sm text-sage">
        <span className="relative flex h-2 w-2">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-sage opacity-60" />
          <span className="relative inline-flex h-2 w-2 rounded-full bg-sage" />
        </span>
        {product.stock > 100 ? "In stock — ships within 48 hours" : `Only ${product.stock} left in stock`}
      </p>
    </div>
  );
}
