"use client";

import { useCallback, useEffect, useState } from "react";
import { Icon } from "@/components/ui";

export function ProductGallery({ images, name }: { images: string[]; name: string }) {
  const [active, setActive] = useState(0);
  const [zoom, setZoom] = useState<{ x: number; y: number } | null>(null);
  const [lightbox, setLightbox] = useState(false);

  const go = useCallback((d: number) => setActive((a) => (a + d + images.length) % images.length), [images.length]);

  useEffect(() => {
    if (!lightbox) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setLightbox(false);
      if (e.key === "ArrowRight") go(1);
      if (e.key === "ArrowLeft") go(-1);
    };
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [lightbox, go]);

  return (
    <div className="flex flex-col-reverse gap-4 md:flex-row">
      <div className="flex gap-3 overflow-x-auto md:w-20 md:flex-col md:overflow-visible">
        {images.map((src, i) => (
          <button
            key={src + i}
            onClick={() => setActive(i)}
            className={`relative aspect-square w-20 shrink-0 overflow-hidden rounded-xl transition ${
              i === active ? "ring-2 ring-ink ring-offset-2 ring-offset-cream" : "opacity-60 hover:opacity-100"
            }`}
            aria-label={`View image ${i + 1}`}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={src} alt="" className="h-full w-full object-cover" />
          </button>
        ))}
      </div>
      <div
        className="group relative aspect-[4/5] flex-1 cursor-zoom-in overflow-hidden rounded-3xl bg-linen"
        onMouseMove={(e) => {
          const r = e.currentTarget.getBoundingClientRect();
          setZoom({ x: ((e.clientX - r.left) / r.width) * 100, y: ((e.clientY - r.top) / r.height) * 100 });
        }}
        onMouseLeave={() => setZoom(null)}
        onClick={() => setLightbox(true)}
      >
        {images.map((src, i) => (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            key={src + i}
            src={src}
            alt={i === 0 ? name : `${name} view ${i + 1}`}
            className={`absolute inset-0 h-full w-full object-cover transition-[opacity,transform] duration-700 ${i === active ? "opacity-100" : "opacity-0"}`}
            style={i === active && zoom ? { transform: "scale(1.6)", transformOrigin: `${zoom.x}% ${zoom.y}%` } : undefined}
          />
        ))}
        <div className="absolute inset-x-4 bottom-4 flex justify-between opacity-0 transition group-hover:opacity-100 max-md:opacity-100">
          <button onClick={(e) => { e.stopPropagation(); go(-1); }} className="grid h-10 w-10 place-items-center rounded-full bg-cream/90 shadow" aria-label="Previous image">
            <Icon name="arrow" className="h-4 w-4 rotate-180" />
          </button>
          <span className="self-center rounded-full bg-cream/90 px-3 py-1 text-xs tabular-nums">{active + 1} / {images.length}</span>
          <button onClick={(e) => { e.stopPropagation(); go(1); }} className="grid h-10 w-10 place-items-center rounded-full bg-cream/90 shadow" aria-label="Next image">
            <Icon name="arrow" className="h-4 w-4" />
          </button>
        </div>
      </div>

      {lightbox && (
        <div className="fixed inset-0 z-[70] flex animate-fade-in items-center justify-center bg-ink/95 p-4" onClick={() => setLightbox(false)}>
          <button className="absolute right-5 top-5 p-2 text-cream" aria-label="Close">
            <Icon name="close" className="h-7 w-7" />
          </button>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={images[active]} alt={name} className="max-h-[88vh] max-w-full rounded-xl object-contain" onClick={(e) => e.stopPropagation()} />
          <button onClick={(e) => { e.stopPropagation(); go(-1); }} className="absolute left-4 top-1/2 grid h-12 w-12 -translate-y-1/2 place-items-center rounded-full bg-cream/10 text-cream hover:bg-cream/20" aria-label="Previous">
            <Icon name="arrow" className="h-5 w-5 rotate-180" />
          </button>
          <button onClick={(e) => { e.stopPropagation(); go(1); }} className="absolute right-4 top-1/2 grid h-12 w-12 -translate-y-1/2 place-items-center rounded-full bg-cream/10 text-cream hover:bg-cream/20" aria-label="Next">
            <Icon name="arrow" className="h-5 w-5" />
          </button>
        </div>
      )}
    </div>
  );
}
