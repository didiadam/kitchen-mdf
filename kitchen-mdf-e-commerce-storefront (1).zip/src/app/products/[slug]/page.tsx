import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getCollections, getProductBySlug, getRelatedProducts, getReviews } from "@/lib/queries";
import { ProductCard } from "@/components/product/ProductCard";
import { Icon, Reveal, Stars } from "@/components/ui";
import { formatDate } from "@/lib/format";
import { ProductGallery } from "./ProductGallery";
import { ProductPurchase } from "./ProductPurchase";
import { ReviewForm } from "./ReviewForm";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) return { title: "Product not found" };
  return { title: product.name, description: product.shortDescription, openGraph: { images: [product.images[0]] } };
}

export default async function ProductPage({ params }: Params) {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) notFound();

  const [reviews, related, collections] = await Promise.all([
    getReviews(product.id),
    getRelatedProducts(product.collectionSlug, product.id),
    getCollections(),
  ]);
  const collection = collections.find((c) => c.slug === product.collectionSlug);
  const breakdown = [5, 4, 3, 2, 1].map((n) => ({ n, count: reviews.filter((r) => r.rating === n).length }));

  return (
    <div className="mx-auto max-w-7xl px-5 pb-24 pt-8">
      <nav className="mb-8 flex flex-wrap items-center gap-2 text-xs text-stone" aria-label="Breadcrumb">
        <Link href="/" className="hover:text-ink">Home</Link>
        <span>/</span>
        <Link href="/shop" className="hover:text-ink">Shop</Link>
        {collection && (
          <>
            <span>/</span>
            <Link href={`/shop?collection=${collection.slug}`} className="hover:text-ink">{collection.name}</Link>
          </>
        )}
        <span>/</span>
        <span className="text-ink">{product.name}</span>
      </nav>

      <div className="grid gap-12 lg:grid-cols-[1.15fr_1fr] lg:gap-16">
        <div className="animate-fade-in lg:sticky lg:top-24 lg:self-start">
          <ProductGallery images={product.images} name={product.name} />
        </div>

        <div className="animate-fade-up">
          {product.badge && (
            <span className="mb-4 inline-block rounded-full bg-brass/15 px-3 py-1 text-[0.65rem] font-semibold uppercase tracking-wider text-brass">
              {product.badge}
            </span>
          )}
          <p className="eyebrow">{collection?.name}</p>
          <h1 className="mt-2 text-4xl leading-tight md:text-5xl">{product.name}</h1>
          <a href="#reviews" className="mt-3 inline-flex items-center gap-2 text-sm">
            <Stars rating={product.rating} />
            <span className="text-stone underline-offset-4 hover:underline">
              {product.rating.toFixed(1)} · {product.reviewCount} reviews
            </span>
          </a>
          <p className="mt-6 text-lg leading-relaxed text-graphite">{product.shortDescription}</p>

          <div className="mt-8 border-t border-ink/10 pt-8">
            <ProductPurchase
              product={{
                id: product.id,
                slug: product.slug,
                name: product.name,
                image: product.images[0],
                unit: product.unit,
                compareAtPrice: product.compareAtPrice,
                basePrice: product.price,
                stock: product.stock,
              }}
              variants={product.variants}
            />
          </div>

          <ul className="mt-8 grid gap-3 rounded-2xl bg-linen/70 p-6 sm:grid-cols-3">
            {product.highlights.map((h) => (
              <li key={h} className="flex items-start gap-2 text-sm">
                <Icon name="check" className="mt-0.5 h-4 w-4 shrink-0 text-sage" /> {h}
              </li>
            ))}
          </ul>

          <div className="mt-8 divide-y divide-ink/10 border-y border-ink/10">
            <details open className="group py-5">
              <summary className="flex cursor-pointer list-none items-center justify-between font-display text-lg">
                Description <Icon name="chevron" className="h-4 w-4 transition-transform group-open:rotate-180" />
              </summary>
              <p className="mt-4 text-sm leading-relaxed text-graphite">{product.description}</p>
            </details>
            <details className="group py-5">
              <summary className="flex cursor-pointer list-none items-center justify-between font-display text-lg">
                Specifications <Icon name="chevron" className="h-4 w-4 transition-transform group-open:rotate-180" />
              </summary>
              <dl className="mt-4 divide-y divide-ink/5 text-sm">
                <SpecRow label="Finish" value={product.finish} />
                <SpecRow label="Nominal thickness" value={`${product.thickness} mm`} />
                <SpecRow label="Moisture resistant" value={product.moistureResistant ? "Yes (MR grade)" : "No"} />
                {product.specs.map((s) => (
                  <SpecRow key={s.label} label={s.label} value={s.value} />
                ))}
              </dl>
            </details>
            <details className="group py-5">
              <summary className="flex cursor-pointer list-none items-center justify-between font-display text-lg">
                Delivery & returns <Icon name="chevron" className="h-4 w-4 transition-transform group-open:rotate-180" />
              </summary>
              <div className="mt-4 space-y-2 text-sm leading-relaxed text-graphite">
                <p>Standard delivery £29 on our own fleet (free over £500), next-day £59, or free collection from our Sheffield yard.</p>
                <p>Stock boards may be returned unused within 30 days. Made-to-measure and painted items are non-returnable unless faulty — covered by our 5-year finish guarantee.</p>
              </div>
            </details>
          </div>

          <div className="mt-8 grid grid-cols-3 gap-4 text-center text-xs text-stone">
            <div className="flex flex-col items-center gap-2"><Icon name="truck" className="h-6 w-6 text-sage" /> Own-fleet delivery</div>
            <div className="flex flex-col items-center gap-2"><Icon name="shield" className="h-6 w-6 text-sage" /> 5-year guarantee</div>
            <div className="flex flex-col items-center gap-2"><Icon name="leaf" className="h-6 w-6 text-sage" /> FSC® certified</div>
          </div>
        </div>
      </div>

      {/* REVIEWS */}
      <section id="reviews" className="mt-28 scroll-mt-28 grid gap-12 lg:grid-cols-[340px_1fr]">
        <Reveal>
          <div className="lg:sticky lg:top-28">
            <p className="eyebrow">Customer reviews</p>
            <div className="mt-3 flex items-end gap-3">
              <span className="font-display text-6xl">{product.rating.toFixed(1)}</span>
              <div className="pb-2">
                <Stars rating={product.rating} size={16} />
                <p className="mt-1 text-xs text-stone">Based on {product.reviewCount} reviews</p>
              </div>
            </div>
            <div className="mt-6 space-y-2">
              {breakdown.map((b) => (
                <div key={b.n} className="flex items-center gap-3 text-xs">
                  <span className="w-8 tabular-nums text-stone">{b.n} ★</span>
                  <div className="h-2 flex-1 overflow-hidden rounded-full bg-ink/10">
                    <div className="h-full rounded-full bg-brass" style={{ width: `${reviews.length ? (b.count / reviews.length) * 100 : 0}%` }} />
                  </div>
                  <span className="w-6 text-right tabular-nums text-stone">{b.count}</span>
                </div>
              ))}
            </div>
            <div className="mt-8">
              <ReviewForm productId={product.id} />
            </div>
          </div>
        </Reveal>
        <div className="divide-y divide-ink/10">
          {reviews.length === 0 && <p className="text-stone">No reviews yet — be the first.</p>}
          {reviews.map((r, i) => (
            <Reveal key={r.id} delay={Math.min(i, 4) * 60}>
              <article className="py-8 first:pt-0">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <Stars rating={r.rating} />
                  <time className="text-xs text-stone">{formatDate(r.createdAt)}</time>
                </div>
                <h3 className="mt-3 text-xl">{r.title}</h3>
                <p className="mt-2 leading-relaxed text-graphite">{r.body}</p>
                <p className="mt-4 flex items-center gap-2 text-sm">
                  <span className="grid h-8 w-8 place-items-center rounded-full bg-linen font-display text-sm">{r.author.charAt(0)}</span>
                  <span className="font-medium">{r.author}</span>
                  {r.location && <span className="text-stone">· {r.location}</span>}
                  {r.verified && (
                    <span className="ml-1 inline-flex items-center gap-1 rounded-full bg-sage/10 px-2 py-0.5 text-[0.65rem] font-medium text-sage">
                      <Icon name="check" className="h-3 w-3" /> Verified buyer
                    </span>
                  )}
                </p>
              </article>
            </Reveal>
          ))}
        </div>
      </section>

      {related.length > 0 && (
        <section className="mt-28">
          <Reveal className="flex items-end justify-between">
            <h2 className="text-3xl md:text-4xl">You may also like</h2>
            <Link href={`/shop?collection=${product.collectionSlug}`} className="text-sm underline-offset-4 hover:underline">View collection</Link>
          </Reveal>
          <div className="mt-10 grid grid-cols-2 gap-x-5 gap-y-12 lg:grid-cols-4">
            {related.map((p, i) => (
              <Reveal key={p.id} delay={i * 80}>
                <ProductCard product={p} />
              </Reveal>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

function SpecRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-6 py-2.5">
      <dt className="text-stone">{label}</dt>
      <dd className="text-right font-medium">{value}</dd>
    </div>
  );
}
