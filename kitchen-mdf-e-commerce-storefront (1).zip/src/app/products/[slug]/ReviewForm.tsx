"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export function ReviewForm({ productId }: { productId: number }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [rating, setRating] = useState(5);
  const [hover, setHover] = useState(0);
  const [status, setStatus] = useState<"idle" | "saving" | "done" | "error">("idle");
  const [error, setError] = useState("");

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    setStatus("saving");
    setError("");
    const res = await fetch("/api/reviews", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        productId,
        rating,
        author: fd.get("author"),
        location: fd.get("location"),
        title: fd.get("title"),
        body: fd.get("body"),
      }),
    });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error ?? "Something went wrong");
      setStatus("error");
      return;
    }
    setStatus("done");
    router.refresh();
  }

  if (status === "done") {
    return (
      <div className="animate-fade-up rounded-2xl bg-sage/10 p-6 text-sm text-sage-dark">
        <p className="font-display text-xl">Thank you for your review!</p>
        <p className="mt-1">It&apos;s now live on this page and helps other customers choose with confidence.</p>
      </div>
    );
  }

  if (!open) {
    return (
      <button onClick={() => setOpen(true)} className="btn-outline w-full">
        Write a review
      </button>
    );
  }

  return (
    <form onSubmit={submit} className="animate-fade-up space-y-4 rounded-2xl border border-ink/10 bg-white/50 p-6">
      <div>
        <p className="mb-2 text-sm font-medium">Your rating</p>
        <div className="flex gap-1" onMouseLeave={() => setHover(0)}>
          {[1, 2, 3, 4, 5].map((n) => (
            <button
              key={n}
              type="button"
              onMouseEnter={() => setHover(n)}
              onClick={() => setRating(n)}
              className={`text-2xl transition-transform hover:scale-110 ${(hover || rating) >= n ? "text-brass" : "text-ink/15"}`}
              aria-label={`${n} stars`}
            >
              ★
            </button>
          ))}
        </div>
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <input name="author" required maxLength={60} placeholder="Your name" className="field" />
        <input name="location" maxLength={60} placeholder="Town / city (optional)" className="field" />
      </div>
      <input name="title" required maxLength={100} placeholder="Review headline" className="field" />
      <textarea name="body" required minLength={10} maxLength={2000} rows={4} placeholder="What did you make? How was the quality?" className="field resize-none" />
      {error && <p className="text-sm text-red-700">{error}</p>}
      <div className="flex gap-3">
        <button disabled={status === "saving"} className="btn-primary flex-1">
          {status === "saving" ? "Submitting…" : "Submit review"}
        </button>
        <button type="button" onClick={() => setOpen(false)} className="btn-outline">
          Cancel
        </button>
      </div>
    </form>
  );
}
