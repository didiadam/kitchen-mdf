"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, type FormEvent, type ReactNode } from "react";
import { useCart } from "@/components/cart/CartProvider";
import { Icon } from "@/components/ui";
import { FREE_SHIPPING_THRESHOLD, SHIPPING_METHODS, formatPrice, shippingCost, vatIncluded } from "@/lib/format";

export function CheckoutClient() {
  const router = useRouter();
  const { items, subtotal, hydrated, clear, updateQuantity, removeItem } = useCart();
  const [method, setMethod] = useState("standard");
  const [status, setStatus] = useState<"idle" | "placing" | "redirecting">("idle");
  const [error, setError] = useState("");
  const [summaryOpen, setSummaryOpen] = useState(false);
  const [card, setCard] = useState({ number: "", expiry: "", cvc: "", name: "" });

  const shipping = shippingCost(method, subtotal);
  const total = subtotal + shipping;

  async function placeOrder(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    const digits = card.number.replace(/\s/g, "");
    if (digits.length < 15 || !/^\d{2}\/\d{2}$/.test(card.expiry) || card.cvc.length < 3) {
      setError("Please check your card details.");
      return;
    }
    const fd = new FormData(e.currentTarget);
    const get = (k: string) => String(fd.get(k) ?? "");
    setStatus("placing");
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: get("email"),
          shippingMethod: method,
          address: {
            firstName: get("firstName"),
            lastName: get("lastName"),
            company: get("company"),
            address1: get("address1"),
            address2: get("address2"),
            city: get("city"),
            postcode: get("postcode"),
            country: get("country"),
            phone: get("phone"),
          },
          items: items.map((i) => ({ productId: i.productId, variantId: i.variantId, quantity: i.quantity })),
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error ?? "We couldn't place your order. Please try again.");
      setStatus("redirecting");
      clear();
      router.push(`/order/${data.reference}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
      setStatus("idle");
    }
  }

  if (!hydrated || status === "redirecting") {
    return (
      <div className="grid min-h-[60vh] place-items-center">
        <div className="flex flex-col items-center gap-4 text-stone">
          <span className="h-8 w-8 animate-spin rounded-full border-2 border-ink/15 border-t-sage" />
          {status === "redirecting" && <p className="text-sm">Confirming your order…</p>}
        </div>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="mx-auto flex min-h-[60vh] max-w-md flex-col items-center justify-center px-5 text-center">
        <h1 className="text-4xl">Your basket is empty</h1>
        <p className="mt-3 text-stone">Add some boards, doors or panels to get started.</p>
        <Link href="/shop" className="btn-primary mt-8">Browse the shop</Link>
      </div>
    );
  }

  const summary = (
    <div>
      <ul className="divide-y divide-ink/10">
        {items.map((i) => (
          <li key={i.key} className="flex items-center gap-4 py-4">
            <div className="relative h-16 w-16 shrink-0">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={i.image} alt={i.name} className="h-full w-full rounded-lg object-cover" />
              <span className="absolute -right-2 -top-2 grid h-5 min-w-5 place-items-center rounded-full bg-graphite px-1 text-[0.65rem] text-white">{i.quantity}</span>
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium">{i.name}</p>
              <p className="text-xs text-stone">{i.variantLabel}</p>
              <div className="mt-1 flex gap-3 text-xs text-stone">
                <button type="button" onClick={() => updateQuantity(i.key, i.quantity - 1)} className="hover:text-ink">−</button>
                <button type="button" onClick={() => updateQuantity(i.key, i.quantity + 1)} className="hover:text-ink">+</button>
                <button type="button" onClick={() => removeItem(i.key)} className="hover:text-ink">Remove</button>
              </div>
            </div>
            <p className="text-sm tabular-nums">{formatPrice(i.price * i.quantity)}</p>
          </li>
        ))}
      </ul>
      <dl className="mt-4 space-y-2.5 border-t border-ink/10 pt-5 text-sm">
        <Row label="Subtotal" value={formatPrice(subtotal)} />
        <Row label="Delivery" value={shipping === 0 ? "Free" : formatPrice(shipping)} />
        {method === "standard" && subtotal < FREE_SHIPPING_THRESHOLD && (
          <p className="text-xs text-sage">Add {formatPrice(FREE_SHIPPING_THRESHOLD - subtotal)} more for free standard delivery</p>
        )}
        <div className="flex items-baseline justify-between border-t border-ink/10 pt-4">
          <dt className="font-medium">Total</dt>
          <dd className="font-display text-3xl">{formatPrice(total)}</dd>
        </div>
        <p className="text-right text-xs text-stone">Including {formatPrice(vatIncluded(total))} VAT</p>
      </dl>
    </div>
  );

  return (
    <div className="mx-auto max-w-6xl px-5 pb-24">
      {/* mobile summary toggle */}
      <div className="-mx-5 border-b border-ink/10 bg-linen/70 px-5 lg:hidden">
        <button type="button" onClick={() => setSummaryOpen((v) => !v)} className="flex w-full items-center justify-between py-4 text-sm">
          <span className="flex items-center gap-2 text-sage-dark">
            <Icon name="bag" className="h-4 w-4" /> {summaryOpen ? "Hide" : "Show"} order summary
            <Icon name="chevron" className={`h-4 w-4 transition-transform ${summaryOpen ? "rotate-180" : ""}`} />
          </span>
          <span className="font-display text-lg">{formatPrice(total)}</span>
        </button>
        <div className={`overflow-hidden transition-[max-height] duration-500 ${summaryOpen ? "max-h-[1200px] pb-6" : "max-h-0"}`}>{summary}</div>
      </div>

      <div className="grid gap-12 pt-10 lg:grid-cols-[1.3fr_1fr]">
        <form onSubmit={placeOrder} className="animate-fade-up space-y-10">
          <div>
            <h1 className="text-4xl">Checkout</h1>
            <ol className="mt-4 flex items-center gap-3 text-xs text-stone">
              <li className="text-ink">Basket</li><li>›</li><li className="font-medium text-ink">Details & payment</li><li>›</li><li>Confirmation</li>
            </ol>
          </div>

          <Section n={1} title="Contact">
            <input name="email" type="email" required autoComplete="email" placeholder="Email address" className="field" />
            <label className="mt-3 flex items-center gap-2 text-xs text-stone">
              <input type="checkbox" defaultChecked className="accent-sage" /> Email me about new finishes and trade offers
            </label>
          </Section>

          <Section n={2} title="Delivery address">
            <div className="grid gap-3 sm:grid-cols-2">
              <input name="firstName" required autoComplete="given-name" placeholder="First name" className="field" />
              <input name="lastName" required autoComplete="family-name" placeholder="Last name" className="field" />
              <input name="company" autoComplete="organization" placeholder="Company (optional)" className="field sm:col-span-2" />
              <input name="address1" required autoComplete="address-line1" placeholder="Address" className="field sm:col-span-2" />
              <input name="address2" autoComplete="address-line2" placeholder="Apartment, unit, etc. (optional)" className="field sm:col-span-2" />
              <input name="city" required autoComplete="address-level2" placeholder="Town / city" className="field" />
              <input name="postcode" required autoComplete="postal-code" placeholder="Postcode" className="field uppercase" />
              <select name="country" className="field" defaultValue="United Kingdom">
                <option>United Kingdom</option>
                <option>Ireland</option>
              </select>
              <input name="phone" type="tel" autoComplete="tel" placeholder="Phone (for delivery driver)" className="field" />
            </div>
          </Section>

          <Section n={3} title="Delivery method">
            <div className="space-y-3">
              {SHIPPING_METHODS.map((m) => {
                const cost = shippingCost(m.id, subtotal);
                return (
                  <label
                    key={m.id}
                    className={`flex cursor-pointer items-center gap-4 rounded-xl border p-4 transition ${
                      method === m.id ? "border-ink bg-white shadow-sm" : "border-ink/15 hover:border-ink/40"
                    }`}
                  >
                    <input type="radio" name="shipping" checked={method === m.id} onChange={() => setMethod(m.id)} className="h-4 w-4 accent-sage" />
                    <span className="flex-1">
                      <span className="block text-sm font-medium">{m.label}</span>
                      <span className="block text-xs text-stone">{m.detail}</span>
                    </span>
                    <span className="text-sm font-medium">{cost === 0 ? "Free" : formatPrice(cost)}</span>
                  </label>
                );
              })}
            </div>
          </Section>

          <Section n={4} title="Payment">
            <div className="rounded-xl border border-ink/15 bg-white/60 p-5">
              <div className="mb-4 flex items-center justify-between">
                <span className="flex items-center gap-2 text-sm font-medium"><Icon name="lock" className="h-4 w-4 text-sage" /> Card</span>
                <button
                  type="button"
                  onClick={() => setCard({ number: "4242 4242 4242 4242", expiry: "12/29", cvc: "123", name: "Demo Customer" })}
                  className="text-xs text-sage underline underline-offset-4"
                >
                  Use test card
                </button>
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <input
                  value={card.number}
                  onChange={(e) => setCard({ ...card, number: e.target.value.replace(/\D/g, "").slice(0, 16).replace(/(.{4})/g, "$1 ").trim() })}
                  inputMode="numeric"
                  autoComplete="cc-number"
                  placeholder="Card number"
                  required
                  className="field tabular-nums sm:col-span-2"
                />
                <input
                  value={card.expiry}
                  onChange={(e) => {
                    const d = e.target.value.replace(/\D/g, "").slice(0, 4);
                    setCard({ ...card, expiry: d.length > 2 ? `${d.slice(0, 2)}/${d.slice(2)}` : d });
                  }}
                  inputMode="numeric"
                  autoComplete="cc-exp"
                  placeholder="MM/YY"
                  required
                  className="field tabular-nums"
                />
                <input
                  value={card.cvc}
                  onChange={(e) => setCard({ ...card, cvc: e.target.value.replace(/\D/g, "").slice(0, 4) })}
                  inputMode="numeric"
                  autoComplete="cc-csc"
                  placeholder="Security code"
                  required
                  className="field tabular-nums"
                />
                <input
                  value={card.name}
                  onChange={(e) => setCard({ ...card, name: e.target.value })}
                  autoComplete="cc-name"
                  placeholder="Name on card"
                  required
                  className="field sm:col-span-2"
                />
              </div>
              <p className="mt-3 text-xs text-stone">Demo storefront — no real payment is taken. Card details never leave your browser.</p>
            </div>
          </Section>

          {error && <p className="animate-fade-in rounded-xl bg-red-50 px-4 py-3 text-sm text-red-800">{error}</p>}

          <button disabled={status === "placing"} className="btn-primary w-full py-4 text-base">
            {status === "placing" ? (
              <><span className="h-4 w-4 animate-spin rounded-full border-2 border-cream/30 border-t-cream" /> Placing order…</>
            ) : (
              <><Icon name="lock" className="h-4 w-4" /> Pay {formatPrice(total)}</>
            )}
          </button>
          <Link href="/shop" className="block text-center text-sm text-stone underline-offset-4 hover:underline">← Continue shopping</Link>
        </form>

        <aside className="hidden lg:block">
          <div className="sticky top-8 rounded-3xl bg-linen/70 p-8">
            <h2 className="text-2xl">Order summary</h2>
            <div className="mt-2">{summary}</div>
            <div className="mt-6 grid grid-cols-3 gap-3 border-t border-ink/10 pt-6 text-center text-[0.7rem] text-stone">
              <span className="flex flex-col items-center gap-1.5"><Icon name="lock" className="h-5 w-5 text-sage" />Secure SSL</span>
              <span className="flex flex-col items-center gap-1.5"><Icon name="truck" className="h-5 w-5 text-sage" />Own fleet</span>
              <span className="flex flex-col items-center gap-1.5"><Icon name="shield" className="h-5 w-5 text-sage" />5-yr guarantee</span>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

function Section({ n, title, children }: { n: number; title: string; children: ReactNode }) {
  return (
    <section>
      <h2 className="mb-4 flex items-center gap-3 text-2xl">
        <span className="grid h-7 w-7 place-items-center rounded-full bg-ink font-sans text-xs text-cream">{n}</span>
        {title}
      </h2>
      {children}
    </section>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between">
      <dt className="text-stone">{label}</dt>
      <dd className="tabular-nums">{value}</dd>
    </div>
  );
}
