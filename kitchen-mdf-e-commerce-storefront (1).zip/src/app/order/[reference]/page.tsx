import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getOrderByReference } from "@/lib/queries";
import { SHIPPING_METHODS, formatDate, formatPrice } from "@/lib/format";
import { Icon } from "@/components/ui";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Order confirmed" };

export default async function OrderPage({ params }: { params: Promise<{ reference: string }> }) {
  const { reference } = await params;
  const order = await getOrderByReference(reference);
  if (!order) notFound();
  const method = SHIPPING_METHODS.find((m) => m.id === order.shippingMethod);
  const a = order.address;

  return (
    <div className="mx-auto max-w-3xl px-5 py-16 md:py-24">
      <div className="animate-fade-up text-center">
        <span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-sage text-cream shadow-lg">
          <Icon name="check" className="h-8 w-8" />
        </span>
        <p className="eyebrow mt-6">Order {order.reference}</p>
        <h1 className="mt-3 text-4xl md:text-5xl">Thank you, {a.firstName}.</h1>
        <p className="mx-auto mt-4 max-w-lg text-stone">
          Your order is confirmed and our workshop team has been notified. A confirmation has been sent to <strong className="text-ink">{order.email}</strong>.
        </p>
      </div>

      <div className="mt-12 animate-fade-up rounded-3xl bg-linen/70 p-6 [animation-delay:150ms] md:p-10">
        <ol className="grid grid-cols-4 gap-2 text-center text-[0.7rem] text-stone">
          {["Confirmed", "In workshop", "Dispatched", "Delivered"].map((s, i) => (
            <li key={s} className="flex flex-col items-center gap-2">
              <span className={`h-2 w-full rounded-full ${i === 0 ? "bg-sage" : "bg-ink/10"}`} />
              <span className={i === 0 ? "font-medium text-ink" : ""}>{s}</span>
            </li>
          ))}
        </ol>

        <ul className="mt-8 divide-y divide-ink/10">
          {order.items.map((i) => (
            <li key={`${i.productId}-${i.variantId}`} className="flex items-center gap-4 py-4">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={i.image} alt={i.name} className="h-16 w-16 rounded-lg object-cover" />
              <div className="flex-1">
                <Link href={`/products/${i.slug}`} className="font-display text-lg hover:text-sage">{i.name}</Link>
                <p className="text-xs text-stone">{i.variantLabel} · Qty {i.quantity}</p>
              </div>
              <p className="tabular-nums">{formatPrice(i.unitPrice * i.quantity)}</p>
            </li>
          ))}
        </ul>

        <dl className="mt-4 space-y-2 border-t border-ink/10 pt-5 text-sm">
          <div className="flex justify-between"><dt className="text-stone">Subtotal</dt><dd>{formatPrice(order.subtotal)}</dd></div>
          <div className="flex justify-between"><dt className="text-stone">{method?.label ?? "Delivery"}</dt><dd>{order.shipping === 0 ? "Free" : formatPrice(order.shipping)}</dd></div>
          <div className="flex items-baseline justify-between border-t border-ink/10 pt-3">
            <dt className="font-medium">Total paid</dt>
            <dd className="font-display text-3xl">{formatPrice(order.total)}</dd>
          </div>
          <p className="text-right text-xs text-stone">Including {formatPrice(order.tax)} VAT</p>
        </dl>

        <div className="mt-8 grid gap-6 border-t border-ink/10 pt-8 text-sm sm:grid-cols-2">
          <div>
            <h3 className="font-sans text-xs font-semibold uppercase tracking-[0.2em] text-stone">Delivering to</h3>
            <p className="mt-2 leading-relaxed">
              {a.firstName} {a.lastName}<br />
              {a.company && <>{a.company}<br /></>}
              {a.address1}<br />
              {a.address2 && <>{a.address2}<br /></>}
              {a.city}, {a.postcode}<br />
              {a.country}
            </p>
          </div>
          <div>
            <h3 className="font-sans text-xs font-semibold uppercase tracking-[0.2em] text-stone">Details</h3>
            <p className="mt-2 leading-relaxed">
              Placed {formatDate(order.createdAt)}<br />
              {method?.label} — {method?.detail}
            </p>
          </div>
        </div>
      </div>

      <div className="mt-10 flex flex-wrap justify-center gap-3">
        <Link href="/shop" className="btn-primary">Continue shopping</Link>
        <Link href="/" className="btn-outline">Back to home</Link>
      </div>
    </div>
  );
}
