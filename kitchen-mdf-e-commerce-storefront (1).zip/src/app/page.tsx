import Link from "next/link";
import { getCollections, getFeaturedProducts, getLatestReviews, getProducts } from "@/lib/queries";
import { ProductCard } from "@/components/product/ProductCard";
import { Icon, Reveal, Stars } from "@/components/ui";
import { IMG } from "@/lib/seed-data";

export const dynamic = "force-dynamic";

const FINISHES = [
  { name: "Sage", hex: "#6f7d68", slug: "hartley-shaker-door-sage" },
  { name: "Navy", hex: "#23304a", slug: "hartley-drawer-front-navy" },
  { name: "Charcoal", hex: "#34353a", slug: "linea-j-pull-door-charcoal" },
  { name: "Oat", hex: "#e3d8c4", slug: "ashby-slab-door-oat" },
  { name: "Primed", hex: "#f4f2ee", slug: "hartley-shaker-door-primed" },
  { name: "Oak", hex: "#c79d6a", slug: "crown-cut-oak-veneered-mdf" },
];

export default async function HomePage() {
  const [collections, featured, testimonials, all] = await Promise.all([
    getCollections(),
    getFeaturedProducts(8),
    getLatestReviews(3),
    getProducts(),
  ]);
  const totalReviews = all.reduce((s, p) => s + p.reviewCount, 0);
  const avgRating = all.reduce((s, p) => s + p.rating * p.reviewCount, 0) / Math.max(1, totalReviews);

  return (
    <>
      {/* HERO */}
      <section className="relative flex min-h-[100svh] items-end overflow-hidden bg-ink text-cream">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={IMG.hero} alt="Sage green shaker MDF kitchen" className="absolute inset-0 h-full w-full animate-slow-zoom object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink/85 via-ink/30 to-ink/40" />
        <div className="relative mx-auto w-full max-w-7xl px-5 pb-16 pt-40 md:pb-24">
          <p className="eyebrow animate-fade-up text-brass-light">Board to Door · Est. 2009</p>
          <h1 className="mt-5 max-w-4xl animate-fade-up text-5xl leading-[1.02] [animation-delay:120ms] sm:text-6xl md:text-7xl lg:text-8xl">
            From raw MDF to <em className="font-light italic text-brass-light">the kitchen</em> you&apos;ve imagined.
          </h1>
          <p className="mt-6 max-w-xl animate-fade-up text-base leading-relaxed text-cream/80 [animation-delay:240ms] md:text-lg">
            Premium MDF sheets, made-to-measure doors and flawless finishing panels — machined and hand-sprayed in our Sheffield workshop, delivered to your door.
          </p>
          <div className="mt-9 flex animate-fade-up flex-wrap gap-3 [animation-delay:360ms]">
            <Link href="/shop" className="btn-primary bg-cream text-ink hover:bg-brass-light hover:text-ink">
              Shop the collection <Icon name="arrow" className="h-4 w-4" />
            </Link>
            <Link href="/shop?collection=cabinet-doors" className="btn-outline border-cream/40 text-cream hover:border-cream hover:bg-cream hover:text-ink">
              Explore doors
            </Link>
          </div>
          <div className="mt-14 grid max-w-2xl animate-fade-in grid-cols-3 gap-6 border-t border-cream/20 pt-6 [animation-delay:600ms]">
            <Stat value={`${avgRating.toFixed(1)}★`} label={`${totalReviews}+ verified reviews`} />
            <Stat value="10 days" label="Made-to-measure doors" />
            <Stat value="£500+" label="Free UK delivery" />
          </div>
        </div>
      </section>

      {/* MARQUEE */}
      <div className="overflow-hidden border-b border-ink/10 bg-linen py-4">
        <div className="flex w-max animate-marquee gap-12 whitespace-nowrap text-sm text-graphite">
          {[...Array(2)].flatMap((_, k) =>
            ["FSC® certified supply", "E1 low-emission boards", "Precision cut-to-size", "Hand-sprayed 2K lacquers", "Hinge drilling service", "Trade accounts welcome", "Delivered on our own fleet"].map((t) => (
              <span key={`${k}-${t}`} className="flex items-center gap-12">
                {t} <span className="text-brass">✦</span>
              </span>
            )),
          )}
        </div>
      </div>

      {/* COLLECTIONS */}
      <section className="mx-auto max-w-7xl px-5 py-24">
        <Reveal className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div>
            <p className="eyebrow">Featured collections</p>
            <h2 className="mt-3 max-w-xl text-4xl leading-tight md:text-5xl">Everything a beautiful kitchen is made of.</h2>
          </div>
          <Link href="/shop" className="group inline-flex items-center gap-2 text-sm font-medium">
            View all products <Icon name="arrow" className="h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </Reveal>
        <div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-12">
          {collections.map((c, i) => (
            <Reveal key={c.slug} delay={i * 100} className={i === 0 || i === 3 ? "lg:col-span-7" : "lg:col-span-5"}>
              <Link href={`/shop?collection=${c.slug}`} className="group relative block h-[420px] overflow-hidden rounded-3xl bg-ink md:h-[480px]">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={c.image} alt={c.name} className="absolute inset-0 h-full w-full object-cover opacity-90 transition-transform duration-[1.4s] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-105" />
                <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-ink/10 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-7 text-cream md:p-9">
                  <p className="text-xs uppercase tracking-[0.25em] text-brass-light">{c.tagline}</p>
                  <h3 className="mt-2 text-3xl md:text-4xl">{c.name}</h3>
                  <p className="mt-3 max-w-md text-sm leading-relaxed text-cream/75 opacity-0 transition-all duration-500 group-hover:opacity-100 max-md:opacity-100">
                    {c.description}
                  </p>
                  <span className="mt-5 inline-flex items-center gap-2 text-sm font-medium">
                    Shop {c.name} <Icon name="arrow" className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </span>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      </section>

      {/* BEST SELLERS */}
      <section className="bg-linen/60 py-24">
        <div className="mx-auto max-w-7xl px-5">
          <Reveal className="text-center">
            <p className="eyebrow">Most loved</p>
            <h2 className="mt-3 text-4xl md:text-5xl">Best sellers</h2>
            <p className="mx-auto mt-4 max-w-lg text-stone">The boards, doors and panels our customers and trade partners come back for again and again.</p>
          </Reveal>
          <div className="mt-14 grid grid-cols-2 gap-x-5 gap-y-12 lg:grid-cols-4">
            {featured.map((p, i) => (
              <Reveal key={p.id} delay={(i % 4) * 90}>
                <ProductCard product={p} priority={i < 4} />
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* STORY / PROCESS */}
      <section className="mx-auto grid max-w-7xl items-center gap-14 px-5 py-24 lg:grid-cols-2">
        <Reveal className="relative">
          <div className="aspect-[4/5] overflow-hidden rounded-3xl">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={IMG.workshop} alt="Craftsman inspecting a sprayed MDF door" className="h-full w-full object-cover" />
          </div>
          <div className="absolute -bottom-8 -right-4 hidden w-56 rounded-2xl bg-cream p-5 shadow-2xl md:block">
            <p className="font-display text-4xl text-sage">15+</p>
            <p className="mt-1 text-sm text-stone">years machining MDF for British kitchens</p>
          </div>
        </Reveal>
        <Reveal delay={150}>
          <p className="eyebrow">Board to door</p>
          <h2 className="mt-3 text-4xl leading-tight md:text-5xl">MDF, perfected at every step.</h2>
          <p className="mt-5 text-lg leading-relaxed text-stone">
            We begin with the finest European boards and finish with doors good enough to sit in a showroom. Because we control every stage, you get consistency that merchants simply can&apos;t match.
          </p>
          <ol className="mt-10 space-y-7">
            {[
              ["Select", "E1, FSC® certified MDF — standard, moisture resistant or fire rated."],
              ["Machine", "5-axis CNC routing to ±0.2mm, one piece, no joints."],
              ["Finish", "Primed, or hand-sprayed with three coats of 2K lacquer."],
              ["Deliver", "Individually wrapped and delivered on our own fleet."],
            ].map(([t, d], i) => (
              <li key={t} className="flex gap-5">
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full border border-brass font-display text-brass">{i + 1}</span>
                <div>
                  <h3 className="text-xl">{t}</h3>
                  <p className="mt-1 text-sm leading-relaxed text-stone">{d}</p>
                </div>
              </li>
            ))}
          </ol>
        </Reveal>
      </section>

      {/* FINISHES */}
      <section className="grain bg-sage-dark py-24 text-cream">
        <div className="mx-auto max-w-7xl px-5">
          <Reveal className="grid gap-10 lg:grid-cols-[1fr_1.4fr] lg:items-center">
            <div>
              <p className="eyebrow text-brass-light">The palette</p>
              <h2 className="mt-3 text-4xl leading-tight md:text-5xl">Six signature finishes, endlessly combinable.</h2>
              <p className="mt-5 max-w-md text-cream/70">
                Mix a Sage run with a Navy island, or pair Oat slabs with warm oak veneer. Every colour is batch-matched across doors, drawers and panels.
              </p>
            </div>
            <div className="grid grid-cols-3 gap-4 sm:grid-cols-6 lg:grid-cols-3">
              {FINISHES.map((f, i) => (
                <Link key={f.name} href={`/products/${f.slug}`} className="group text-center" style={{ transitionDelay: `${i * 60}ms` }}>
                  <span
                    className="mx-auto block aspect-square w-full max-w-[120px] rounded-2xl shadow-lg ring-1 ring-cream/10 transition-transform duration-500 group-hover:-translate-y-2 group-hover:rotate-2"
                    style={{ background: f.hex }}
                  />
                  <span className="mt-3 block text-sm">{f.name}</span>
                </Link>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      {/* LOOKBOOK */}
      <section className="mx-auto max-w-7xl px-5 py-24">
        <Reveal className="text-center">
          <p className="eyebrow">Inspiration</p>
          <h2 className="mt-3 text-4xl md:text-5xl">Kitchens made with Kitchen MDF</h2>
        </Reveal>
        <div className="mt-12 grid auto-rows-[220px] grid-cols-2 gap-4 md:auto-rows-[260px] md:grid-cols-4">
          {[
            [IMG.kitchenMatte, "md:col-span-2 md:row-span-2"],
            [IMG.blueKitchen, ""],
            [IMG.kitchenOak, ""],
            [IMG.kitchenMono, "col-span-2"],
          ].map(([src, cls], i) => (
            <Reveal key={src} delay={i * 80} className={`overflow-hidden rounded-2xl ${cls}`}>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={src} alt="Customer kitchen" loading="lazy" className="h-full w-full object-cover transition-transform duration-[1.4s] hover:scale-105" />
            </Reveal>
          ))}
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="bg-linen/60 py-24">
        <div className="mx-auto max-w-7xl px-5">
          <Reveal className="flex flex-col items-center text-center">
            <Stars rating={avgRating} size={20} />
            <h2 className="mt-4 text-4xl md:text-5xl">Rated {avgRating.toFixed(1)} out of 5</h2>
            <p className="mt-3 text-stone">From {totalReviews} verified reviews by homeowners, joiners and fitters.</p>
          </Reveal>
          <div className="mt-14 grid gap-6 md:grid-cols-3">
            {testimonials.map((r, i) => (
              <Reveal key={r.id} delay={i * 120}>
                <figure className="flex h-full flex-col rounded-3xl bg-cream p-8 shadow-[0_20px_50px_-25px_rgba(0,0,0,0.25)]">
                  <Stars rating={r.rating} />
                  <blockquote className="mt-5 flex-1">
                    <p className="font-display text-xl leading-snug">&ldquo;{r.title}&rdquo;</p>
                    <p className="mt-3 text-sm leading-relaxed text-stone">{r.body}</p>
                  </blockquote>
                  <figcaption className="mt-6 border-t border-ink/10 pt-5 text-sm">
                    <span className="font-medium">{r.author}</span>
                    <span className="text-stone"> · {r.location}</span>
                    <Link href={`/products/${r.productSlug}`} className="mt-1 block text-xs text-sage hover:underline">
                      on {r.productName}
                    </Link>
                  </figcaption>
                </figure>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* VALUE PROPS + TRADE CTA */}
      <section className="mx-auto max-w-7xl px-5 py-24">
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {[
            ["truck", "Own-fleet delivery", "Boards arrive flat, doors arrive perfect."],
            ["ruler", "Cut to size", "Any dimension, to ±0.2mm tolerance."],
            ["leaf", "Responsibly sourced", "FSC® certified, E1 low emission."],
            ["shield", "5-year finish guarantee", "On every factory-sprayed door."],
          ].map(([icon, t, d], i) => (
            <Reveal key={t} delay={i * 80} className="flex gap-4">
              <span className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-linen text-sage">
                <Icon name={icon as "truck"} />
              </span>
              <div>
                <h3 className="font-sans text-sm font-semibold">{t}</h3>
                <p className="mt-1 text-sm text-stone">{d}</p>
              </div>
            </Reveal>
          ))}
        </div>
        <Reveal className="relative mt-20 overflow-hidden rounded-[2rem] bg-ink text-cream">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={IMG.saw} alt="" className="absolute inset-0 h-full w-full object-cover opacity-30" />
          <div className="relative grid gap-8 p-10 md:grid-cols-[1.5fr_1fr] md:items-center md:p-16">
            <div>
              <p className="eyebrow text-brass-light">For joiners, fitters & designers</p>
              <h2 className="mt-3 text-4xl leading-tight md:text-5xl">MDF to the trade, at trade prices.</h2>
              <p className="mt-4 max-w-lg text-cream/70">Open a trade account for tiered pricing, 30-day terms, scheduled deliveries and a dedicated account manager.</p>
            </div>
            <div className="flex md:justify-end">
              <Link href="/shop?collection=mdf-boards" className="btn-primary bg-brass text-ink hover:bg-brass-light hover:text-ink">
                Shop trade boards <Icon name="arrow" className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </Reveal>
      </section>
    </>
  );
}

function Stat({ value, label }: { value: string; label: string }) {
  return (
    <div>
      <p className="font-display text-2xl md:text-3xl">{value}</p>
      <p className="mt-1 text-xs text-cream/60">{label}</p>
    </div>
  );
}
