import type { Metadata } from "next";
import { getCollections, getProducts } from "@/lib/queries";
import { ShopClient } from "./ShopClient";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Shop MDF Boards, Doors & Panels",
  description: "Browse premium MDF sheets, cabinet doors, lacquered & veneered panels and kitchen components.",
};

export default async function ShopPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const [products, collections] = await Promise.all([getProducts(), getCollections()]);
  const collection = typeof sp.collection === "string" ? sp.collection : "all";
  const sort = typeof sp.sort === "string" ? sp.sort : "featured";
  const q = typeof sp.q === "string" ? sp.q : "";
  const active = collections.find((c) => c.slug === collection);

  return (
    <div>
      <section className="border-b border-ink/10 bg-linen/60">
        <div className="mx-auto max-w-7xl px-5 pb-12 pt-14 md:pt-20">
          <p className="eyebrow animate-fade-up">{active ? active.tagline : "The full range"}</p>
          <h1 className="mt-3 animate-fade-up text-5xl [animation-delay:100ms] md:text-6xl">{active ? active.name : "Shop all"}</h1>
          <p className="mt-4 max-w-2xl animate-fade-up text-stone [animation-delay:200ms]">
            {active
              ? active.description
              : "Premium MDF sheets, made-to-measure doors, lacquered and veneered panels and every finishing component — all in one place."}
          </p>
        </div>
      </section>
      <ShopClient
        key={`${collection}-${q}`}
        products={products}
        collections={collections.map((c) => ({ slug: c.slug, name: c.name }))}
        initial={{ collection, sort, q }}
      />
    </div>
  );
}
