"use client";

import { usePathname } from "next/navigation";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import type { Product } from "@/db/schema";
import { ProductCard } from "@/components/product/ProductCard";
import { Icon, Stars } from "@/components/ui";
import { formatPrice } from "@/lib/format";

type Props = {
  products: Product[];
  collections: { slug: string; name: string }[];
  initial: { collection: string; sort: string; q: string };
};

const SORTS = [
  { id: "featured", label: "Featured" },
  { id: "price-asc", label: "Price: low to high" },
  { id: "price-desc", label: "Price: high to low" },
  { id: "rating", label: "Top rated" },
  { id: "newest", label: "Newest" },
];

export function ShopClient({ products, collections, initial }: Props) {
  const pathname = usePathname();
  const maxPossible = useMemo(() => Math.ceil(Math.max(...products.map((p) => p.price)) / 1000) * 1000, [products]);

  const [collection, setCollection] = useState(initial.collection);
  const [sort, setSort] = useState(initial.sort);
  const [q, setQ] = useState(initial.q);
  const [finishes, setFinishes] = useState<string[]>([]);
  const [thicknesses, setThicknesses] = useState<number[]>([]);
  const [mrOnly, setMrOnly] = useState(false);
  const [onSale, setOnSale] = useState(false);
  const [minRating, setMinRating] = useState(0);
  const [maxPrice, setMaxPrice] = useState(maxPossible);
  const [drawer, setDrawer] = useState(false);

  const allFinishes = useMemo(() => [...new Set(products.map((p) => p.finish))].sort(), [products]);
  const allThickness = useMemo(() => [...new Set(products.map((p) => p.thickness))].sort((a, b) => a - b), [products]);

  // keep URL shareable
  useEffect(() => {
    const params = new URLSearchParams();
    if (collection !== "all") params.set("collection", collection);
    if (sort !== "featured") params.set("sort", sort);
    if (q) params.set("q", q);
    const qs = params.toString();
    window.history.replaceState(null, "", qs ? `${pathname}?${qs}` : pathname);
  }, [collection, sort, q, pathname]);

  useEffect(() => {
    document.body.style.overflow = drawer ? "hidden" : "";
  }, [drawer]);

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    const list = products.filter((p) => {
      if (collection !== "all" && p.collectionSlug !== collection) return false;
      if (finishes.length && !finishes.includes(p.finish)) return false;
      if (thicknesses.length && !thicknesses.includes(p.thickness)) return false;
      if (mrOnly && !p.moistureResistant) return false;
      if (onSale && !(p.compareAtPrice && p.compareAtPrice > p.price)) return false;
      if (p.rating < minRating) return false;
      if (p.price > maxPrice) return false;
      if (term && !`${p.name} ${p.shortDescription} ${p.finish}`.toLowerCase().includes(term)) return false;
      return true;
    });
    const sorted = [...list];
    switch (sort) {
      case "price-asc": sorted.sort((a, b) => a.price - b.price); break;
      case "price-desc": sorted.sort((a, b) => b.price - a.price); break;
      case "rating": sorted.sort((a, b) => b.rating - a.rating || b.reviewCount - a.reviewCount); break;
      case "newest": sorted.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()); break;
    }
    return sorted;
  }, [products, collection, finishes, thicknesses, mrOnly, onSale, minRating, maxPrice, q, sort]);

  const activeCount =
    (collection !== "all" ? 1 : 0) + finishes.length + thicknesses.length + (mrOnly ? 1 : 0) + (onSale ? 1 : 0) + (minRating ? 1 : 0) + (maxPrice < maxPossible ? 1 : 0);

  const reset = () => {
    setCollection("all");
    setFinishes([]);
    setThicknesses([]);
    setMrOnly(false);
    setOnSale(false);
    setMinRating(0);
    setMaxPrice(maxPossible);
    setQ("");
  };

  const toggle = <T,>(list: T[], v: T, set: (x: T[]) => void) => set(list.includes(v) ? list.filter((x) => x !== v) : [...list, v]);

  const filters = (
    <div className="space-y-8">
      <FilterGroup title="Collection">
        {[{ slug: "all", name: "All products" }, ...collections].map((c) => (
          <label key={c.slug} className="flex cursor-pointer items-center gap-3 py-1 text-sm">
            <input type="radio" name="collection" checked={collection === c.slug} onChange={() => setCollection(c.slug)} className="h-4 w-4 accent-sage" />
            <span className={collection === c.slug ? "font-medium" : "text-graphite"}>{c.name}</span>
            <span className="ml-auto text-xs text-stone">
              {c.slug === "all" ? products.length : products.filter((p) => p.collectionSlug === c.slug).length}
            </span>
          </label>
        ))}
      </FilterGroup>
      <FilterGroup title="Finish">
        <div className="flex flex-wrap gap-2">
          {allFinishes.map((f) => (
            <button
              key={f}
              onClick={() => toggle(finishes, f, setFinishes)}
              className={`rounded-full border px-3.5 py-1.5 text-xs transition ${finishes.includes(f) ? "border-ink bg-ink text-cream" : "border-ink/15 hover:border-ink/50"}`}
            >
              {f}
            </button>
          ))}
        </div>
      </FilterGroup>
      <FilterGroup title="Thickness">
        <div className="flex flex-wrap gap-2">
          {allThickness.map((t) => (
            <button
              key={t}
              onClick={() => toggle(thicknesses, t, setThicknesses)}
              className={`rounded-full border px-3.5 py-1.5 text-xs tabular-nums transition ${thicknesses.includes(t) ? "border-ink bg-ink text-cream" : "border-ink/15 hover:border-ink/50"}`}
            >
              {t} mm
            </button>
          ))}
        </div>
      </FilterGroup>
      <FilterGroup title="Max price">
        <input
          type="range"
          min={1000}
          max={maxPossible}
          step={500}
          value={maxPrice}
          onChange={(e) => setMaxPrice(Number(e.target.value))}
          className="w-full accent-sage"
        />
        <div className="mt-1 flex justify-between text-xs text-stone">
          <span>£10</span>
          <span className="font-medium text-ink">Up to {formatPrice(maxPrice)}</span>
        </div>
      </FilterGroup>
      <FilterGroup title="Rating">
        {[4.5, 4, 0].map((r) => (
          <label key={r} className="flex cursor-pointer items-center gap-3 py-1 text-sm">
            <input type="radio" name="rating" checked={minRating === r} onChange={() => setMinRating(r)} className="h-4 w-4 accent-sage" />
            {r === 0 ? <span className="text-graphite">Any rating</span> : <><Stars rating={r} size={12} /><span className="text-graphite">{r}+</span></>}
          </label>
        ))}
      </FilterGroup>
      <FilterGroup title="Features">
        <Toggle label="Moisture resistant (MR)" checked={mrOnly} onChange={setMrOnly} />
        <Toggle label="On sale" checked={onSale} onChange={setOnSale} />
      </FilterGroup>
      {activeCount > 0 && (
        <button onClick={reset} className="text-sm text-stone underline underline-offset-4 hover:text-ink">
          Clear all filters
        </button>
      )}
    </div>
  );

  return (
    <div className="mx-auto max-w-7xl px-5 py-10">
      {/* toolbar */}
      <div className="sticky top-[73px] z-30 -mx-5 mb-8 flex flex-wrap items-center gap-3 border-b border-ink/10 bg-cream/90 px-5 py-4 backdrop-blur-md">
        <button onClick={() => setDrawer(true)} className="flex items-center gap-2 rounded-full border border-ink/15 px-4 py-2 text-sm lg:hidden">
          <Icon name="filter" className="h-4 w-4" /> Filters {activeCount > 0 && <span className="rounded-full bg-ink px-1.5 text-[0.65rem] text-cream">{activeCount}</span>}
        </button>
        <div className="relative min-w-[180px] flex-1 sm:max-w-xs">
          <Icon name="search" className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-stone" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search boards, doors…" className="field rounded-full py-2 pl-10" />
        </div>
        <p className="hidden text-sm text-stone md:block">
          {filtered.length} {filtered.length === 1 ? "product" : "products"}
        </p>
        <label className="ml-auto flex items-center gap-2 text-sm">
          <span className="hidden text-stone sm:inline">Sort by</span>
          <select value={sort} onChange={(e) => setSort(e.target.value)} className="cursor-pointer rounded-full border border-ink/15 bg-transparent px-4 py-2 text-sm outline-none focus:border-sage">
            {SORTS.map((s) => (
              <option key={s.id} value={s.id}>{s.label}</option>
            ))}
          </select>
        </label>
      </div>

      <div className="grid gap-10 lg:grid-cols-[250px_1fr]">
        <aside className="hidden lg:block">
          <div className="sticky top-[160px]">{filters}</div>
        </aside>
        <div>
          {filtered.length === 0 ? (
            <div className="rounded-3xl border border-dashed border-ink/20 py-24 text-center">
              <h3 className="text-2xl">No products match those filters</h3>
              <p className="mt-2 text-sm text-stone">Try widening your search or clearing a filter.</p>
              <button onClick={reset} className="btn-outline mt-6">Clear filters</button>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-x-5 gap-y-12 xl:grid-cols-3">
              {filtered.map((p, i) => (
                <div key={p.id} className="animate-fade-up" style={{ animationDelay: `${Math.min(i, 8) * 50}ms` }}>
                  <ProductCard product={p} priority={i < 3} />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* mobile drawer */}
      <div className={`fixed inset-0 z-[55] lg:hidden ${drawer ? "" : "pointer-events-none"}`}>
        <div onClick={() => setDrawer(false)} className={`absolute inset-0 bg-ink/40 transition-opacity duration-300 ${drawer ? "opacity-100" : "opacity-0"}`} />
        <div className={`absolute left-0 top-0 flex h-full w-[88%] max-w-sm flex-col bg-cream transition-transform duration-500 ease-[cubic-bezier(0.22,1,0.36,1)] ${drawer ? "translate-x-0" : "-translate-x-full"}`}>
          <div className="flex items-center justify-between border-b border-ink/10 px-5 py-4">
            <h2 className="text-2xl">Filters</h2>
            <button onClick={() => setDrawer(false)} className="p-2" aria-label="Close filters"><Icon name="close" /></button>
          </div>
          <div className="flex-1 overflow-y-auto px-5 py-6">{filters}</div>
          <div className="border-t border-ink/10 p-5">
            <button onClick={() => setDrawer(false)} className="btn-primary w-full">
              Show {filtered.length} products
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function FilterGroup({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div>
      <h3 className="mb-3 font-sans text-[0.7rem] font-semibold uppercase tracking-[0.2em] text-stone">{title}</h3>
      {children}
    </div>
  );
}

function Toggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button type="button" onClick={() => onChange(!checked)} className="flex w-full items-center justify-between py-1.5 text-sm text-graphite">
      {label}
      <span className={`relative h-5 w-9 rounded-full transition ${checked ? "bg-sage" : "bg-ink/15"}`}>
        <span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-all ${checked ? "left-[18px]" : "left-0.5"}`} />
      </span>
    </button>
  );
}
