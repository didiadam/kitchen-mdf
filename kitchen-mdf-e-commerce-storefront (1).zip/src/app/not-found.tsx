import Link from "next/link";

export default function NotFound() {
  return (
    <div className="mx-auto flex min-h-[70vh] max-w-lg flex-col items-center justify-center px-5 text-center">
      <p className="eyebrow">404</p>
      <h1 className="mt-3 text-5xl">This page has been planed away.</h1>
      <p className="mt-4 text-stone">We couldn&apos;t find what you were looking for — but our full range of boards, doors and panels is just a click away.</p>
      <Link href="/shop" className="btn-primary mt-8">Browse the shop</Link>
    </div>
  );
}
