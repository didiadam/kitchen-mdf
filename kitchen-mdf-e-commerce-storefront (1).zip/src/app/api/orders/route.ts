import { inArray } from "drizzle-orm";
import { db } from "@/db";
import { orders, products, type OrderAddress, type OrderItem } from "@/db/schema";
import { SHIPPING_METHODS, shippingCost, vatIncluded } from "@/lib/format";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

const str = (v: unknown, max = 120) => (typeof v === "string" ? v.trim().slice(0, max) : "");

function makeReference() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let s = "";
  for (let i = 0; i < 6; i++) s += alphabet[Math.floor(Math.random() * alphabet.length)];
  return `KM-${s}`;
}

export async function POST(req: Request) {
  await ensureSeeded();
  const body = await req.json().catch(() => null);
  if (!body || typeof body !== "object") return Response.json({ error: "Invalid request" }, { status: 400 });

  const email = str(body.email, 200).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return Response.json({ error: "Please enter a valid email address" }, { status: 400 });

  const a = body.address ?? {};
  const address: OrderAddress = {
    firstName: str(a.firstName, 60),
    lastName: str(a.lastName, 60),
    company: str(a.company, 100) || undefined,
    address1: str(a.address1),
    address2: str(a.address2) || undefined,
    city: str(a.city, 80),
    postcode: str(a.postcode, 12).toUpperCase(),
    country: str(a.country, 60) || "United Kingdom",
    phone: str(a.phone, 30) || undefined,
  };
  if (!address.firstName || !address.lastName || !address.address1 || !address.city || !address.postcode) {
    return Response.json({ error: "Please complete your delivery address" }, { status: 400 });
  }

  const shippingMethod = SHIPPING_METHODS.find((m) => m.id === body.shippingMethod)?.id;
  if (!shippingMethod) return Response.json({ error: "Please choose a delivery method" }, { status: 400 });

  const rawItems: { productId: number; variantId: string; quantity: number }[] = Array.isArray(body.items) ? body.items : [];
  if (rawItems.length === 0 || rawItems.length > 50) return Response.json({ error: "Your basket is empty" }, { status: 400 });

  const ids = [...new Set(rawItems.map((i) => Number(i.productId)).filter((n) => Number.isInteger(n)))];
  const found = ids.length ? await db.select().from(products).where(inArray(products.id, ids)) : [];

  const items: OrderItem[] = [];
  for (const raw of rawItems) {
    const product = found.find((p) => p.id === Number(raw.productId));
    const variant = product?.variants.find((v) => v.id === raw.variantId);
    const quantity = Math.floor(Number(raw.quantity));
    if (!product || !variant || !(quantity >= 1 && quantity <= 99)) {
      return Response.json({ error: "Some items in your basket are no longer available. Please review your basket." }, { status: 409 });
    }
    items.push({
      productId: product.id,
      slug: product.slug,
      name: product.name,
      image: product.images[0],
      variantId: variant.id,
      variantLabel: variant.label,
      unitPrice: variant.price,
      quantity,
    });
  }

  const subtotal = items.reduce((s, i) => s + i.unitPrice * i.quantity, 0);
  const shipping = shippingCost(shippingMethod, subtotal);
  const total = subtotal + shipping;
  const tax = vatIncluded(total);

  for (let attempt = 0; attempt < 5; attempt++) {
    try {
      const [order] = await db
        .insert(orders)
        .values({ reference: makeReference(), email, address, items, shippingMethod, subtotal, shipping, tax, total })
        .returning({ reference: orders.reference });
      return Response.json({ reference: order.reference }, { status: 201 });
    } catch (err) {
      if (attempt === 4) throw err;
    }
  }
  return Response.json({ error: "Could not place order" }, { status: 500 });
}
