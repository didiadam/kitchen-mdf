import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { products, reviews } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

const clean = (v: unknown, max: number) => (typeof v === "string" ? v.trim().slice(0, max) : "");

export async function POST(req: Request) {
  await ensureSeeded();
  const body = await req.json().catch(() => null);
  if (!body) return Response.json({ error: "Invalid request" }, { status: 400 });

  const productId = Number(body.productId);
  const rating = Math.round(Number(body.rating));
  const author = clean(body.author, 60);
  const location = clean(body.location, 60);
  const title = clean(body.title, 100);
  const text = clean(body.body, 2000);

  if (!Number.isInteger(productId) || productId <= 0) return Response.json({ error: "Unknown product" }, { status: 400 });
  if (!(rating >= 1 && rating <= 5)) return Response.json({ error: "Rating must be between 1 and 5" }, { status: 400 });
  if (!author || !title || text.length < 10) return Response.json({ error: "Please complete your name, headline and a review of at least 10 characters" }, { status: 400 });

  const [product] = await db.select({ id: products.id }).from(products).where(eq(products.id, productId)).limit(1);
  if (!product) return Response.json({ error: "Unknown product" }, { status: 404 });

  const [created] = await db
    .insert(reviews)
    .values({ productId, rating, author, location: location || null, title, body: text, verified: false })
    .returning();

  await db
    .update(products)
    .set({
      rating: sql`(select round(avg(rating)::numeric, 1)::real from reviews where product_id = ${productId})`,
      reviewCount: sql`(select count(*)::int from reviews where product_id = ${productId})`,
    })
    .where(eq(products.id, productId));

  return Response.json({ review: created }, { status: 201 });
}
